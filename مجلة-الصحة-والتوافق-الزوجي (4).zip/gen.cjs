const fs = require('fs');
const https = require('https');

async function fetchImageBase64(url) {
    if (!url || !url.startsWith('http')) return url;
    return new Promise((resolve) => {
        let modUrl = url.replace('w=800', 'w=100').replace('q=80', 'q=30');
        https.get(modUrl, (res) => {
            if (res.statusCode !== 200) { resolve(url); return; }
            const chunks = [];
            res.on('data', (c) => chunks.push(c));
            res.on('end', () => resolve('data:' + (res.headers['content-type'] || 'image/jpeg') + ';base64,' + Buffer.concat(chunks).toString('base64')));
        }).on('error', () => resolve(url));
    });
}

const encryptProducts = (products, key) => {
    const text = encodeURIComponent(JSON.stringify(products));
    let result = '';
    for (let i = 0; i < text.length; i++) {
        result += String.fromCharCode(text.charCodeAt(i) ^ key.charCodeAt(i % key.length));
    }
    return Buffer.from(result, 'utf8').toString('base64');
};

const decryptProducts = (encryptedProducts, key) => {
    try {
        const text = Buffer.from(encryptedProducts, 'base64').toString('utf8');
        let result = '';
        for(let i=0; i<text.length; i++) result += String.fromCharCode(text.charCodeAt(i) ^ key.charCodeAt(i % key.length));
        return JSON.parse(decodeURIComponent(result));
    } catch (e) { return []; }
};

async function main() {
    let appCode = fs.readFileSync('src/App.tsx', 'utf8');
    const elderlyMatch = appCode.match(/const elderlyProducts = (\[\s\S]*?\]);/);
    let elderlyProducts = (new Function('return ' + elderlyMatch[1]))();
    const carMatch = appCode.match(/const carProducts = (\[\s\S]*?\]);/);
    let carProducts = (new Function('return ' + carMatch[1]))();
    const encMatch = appCode.match(/const encryptedProducts = \'([^\']+)\'/);
    let encryptedContent = encMatch[1];
    let healthProducts = decryptProducts(encryptedContent, '*12*');

    for (const p of healthProducts) {
        if (!p.image && p.link.includes('oolm7QJ')) p.image = 'https://ae01.alicdn.com/kf/S8f96e8dd12174d81a94254ec9945037dK.jpg';
        if (!p.image && p.link.includes('olN9X2R')) p.image = 'https://ae01.alicdn.com/kf/Sf5f159ab38b8433d9c22e4c4efd46487W.jpg';
        if (!p.image && p.link.includes('oDIW2N1')) p.image = 'https://ae01.alicdn.com/kf/S91f16da88656461c94d0c159074d27572.jpg';
    }

    for (const p of healthProducts) p.image = await fetchImageBase64(p.image);
    for (const p of elderlyProducts) p.image = await fetchImageBase64(p.image);
    for (const p of carProducts) p.image = await fetchImageBase64(p.image);

    const newEncrypted = encryptProducts(healthProducts, '*12*');
    
    fs.writeFileSync('data.json', JSON.stringify({newEncrypted, elderlyProducts, carProducts}));
    console.log('Saved to data.json');
}
main().catch(console.error);
