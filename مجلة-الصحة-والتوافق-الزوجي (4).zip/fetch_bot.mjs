import https from 'https';

const links = [
  "https://amzn.to/43PeM2X",
  "https://amzn.to/4gy1Rdg",
  "https://amzn.to/43OaARa",
  "https://amzn.to/3Sm6ahU",
  "https://amzn.to/4b0Yp7g",
  "https://amzn.to/4wmU7Qf",
  "https://amzn.to/4oCH6PC",
  "https://amzn.to/4vrNxYu",
  "https://amzn.to/4vGTpgN",
  "https://amzn.to/4uQW9a1"
];

async function getRedirectUrl(url) {
  return new Promise((resolve) => {
    https.get(url, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        resolve(res.headers.location);
      } else {
        resolve(url);
      }
    }).on('error', () => resolve(url));
  });
}

async function fetchHtml(url) {
  return new Promise((resolve) => {
    https.get(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5'
      }
    }, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => resolve(data));
    }).on('error', () => resolve(''));
  });
}

async function run() {
  for (let i = 0; i < links.length; i++) {
    const fullUrl = await getRedirectUrl(links[i]);
    const html = await fetchHtml(fullUrl);
    const match = html.match(/"large":"([^"]+)"/);
    const match2 = html.match(/data-old-hires="([^"]+)"/);
    const match3 = html.match(/id="landingImage" data-a-dynamic-image="([^"]+)"/);
    let imageUrl = '';
    if (match) imageUrl = match[1];
    else if (match2) imageUrl = match2[1];
    else if (match3) {
      try {
        const decoded = match3[1].replace(/&quot;/g, '"');
        const urls = Object.keys(JSON.parse(decoded));
        imageUrl = urls[0];
      } catch(e) {}
    }
    console.log(`Product ${i+1}: ${imageUrl || "NOT FOUND"}`);
  }
}
run();
