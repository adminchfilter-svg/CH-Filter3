const fs = require('fs');
const https = require('https');

const fetchImageAsBase64 = (url) => {
    return new Promise((resolve, reject) => {
        // Change width to keep base64 small enough for a code block (e.g. 100px)
        const modifiedUrl = url.replace('w=800', 'w=150').replace('q=80', 'q=50');
        https.get(modifiedUrl, (res) => {
            const chunks = [];
            res.on('data', (chunk) => chunks.push(chunk));
            res.on('end', () => {
                const buffer = Buffer.concat(chunks);
                const base64 = buffer.toString('base64');
                const contentType = res.headers['content-type'] || 'image/jpeg';
                resolve(`data:${contentType};base64,${base64}`);
            });
        }).on('error', reject);
    });
};

const decryptProducts = (encryptedProducts, key) => {
    try {
        const text = Buffer.from(encryptedProducts, 'base64').toString('utf8');
        let result = '';
        for(let i=0; i<text.length; i++) {
            result += String.fromCharCode(text.charCodeAt(i) ^ key.charCodeAt(i % key.length));
        }
        return (new Function('return ' + decodeURIComponent(result))());
    } catch (e) {
        return [];
    }
};

const encryptProducts = (data, key) => {
    const text = encodeURIComponent(JSON.stringify(data));
    let result = '';
    for(let i=0; i<text.length; i++) {
        result += String.fromCharCode(text.charCodeAt(i) ^ key.charCodeAt(i % key.length));
    }
    return Buffer.from(result, 'utf8').toString('base64');
};

async function main() {
    let appCode = fs.readFileSync('src/App.tsx', 'utf8');

    // Extract elderlyProducts
    const elderlyMatch = appCode.match(/const elderlyProducts = (\[[\s\S]*?\]);/);
    let elderlyProducts = (new Function('return ' + elderlyMatch[1]))();

    // Extract carProducts
    const carMatch = appCode.match(/const carProducts = (\[[\s\S]*?\]);/);
    let carProducts = (new Function('return ' + carMatch[1]))();

    // Read encrypted products
    const encryptedContent = fs.readFileSync('encrypted.txt', 'utf8').trim();
    let healthProducts = decryptProducts(encryptedContent, '*12*');

    console.log("Fetching images...");
    for (let p of healthProducts) {
        if (p.image && p.image.startsWith('http')) {
            p.image = await fetchImageAsBase64(p.image);
        }
    }
    for (let p of elderlyProducts) {
        if (p.image && p.image.startsWith('http')) {
            p.image = await fetchImageAsBase64(p.image);
        }
    }
    for (let p of carProducts) {
        if (p.image && p.image.startsWith('http')) {
            p.image = await fetchImageAsBase64(p.image);
        }
    }

    const newEncrypted = encryptProducts(healthProducts, '*12*');

    console.log("Building HTML...");

    // We need to extract the inline HTML content generator from App.tsx
    // Since App.tsx already has the logic to generate HTML, we can just extract it or use a simplified version.
    
    // Instead of doing it dynamically, let's just generate the HTML right here!
    
    // Actually, I can just patch the App.tsx to use the base64 images so that when the user clicks Export HTML, it works.
    // BUT the user wants the HTML code directly in the chat box!
    
    const finalHtml = fs.readFileSync("build-html.js", "utf8").replace("\${newEncrypted}", newEncrypted).replace("\${JSON.stringify(elderlyProducts)}", JSON.stringify(elderlyProducts)).replace("\${JSON.stringify(carProducts)}", JSON.stringify(carProducts)); fs.writeFileSync("standalone.html", finalHtml); console.log("Written to standalone.html"); } main().catch(console.error);