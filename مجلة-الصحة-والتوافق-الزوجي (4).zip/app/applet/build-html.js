import fs from 'fs';
import path from 'path';

const appCode = fs.readFileSync('src/App.tsx', 'utf-8');

// Extract products data
const productsMatch = appCode.match(/const products = \[\s*([\s\S]*?)\s*\];/);
const productsStr = productsMatch ? `[${productsMatch[1]}]` : '[]';

const elderlyMatch = appCode.match(/const elderlyProducts = \[\s*([\s\S]*?)\s*\];/);
const elderlyStr = elderlyMatch ? `[${elderlyMatch[1]}]` : '[]';

const carsMatch = appCode.match(/const carProducts = \[\s*([\s\S]*?)\s*\];/);
const carsStr = carsMatch ? `[${carsMatch[1]}]` : '[]';

// Extract CSS
const cssCode = fs.readFileSync('dist/assets/index-DH3YMKRN.css', 'utf-8');

const html = `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CH-FILTER</title>
    <style>
        ${cssCode}
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap');
        body { font-family: 'Inter', sans-serif; background-color: #FFFFF0; margin: 0; padding: 0; }
        .page { display: none; }
        .active-page { display: block; }
    </style>
</head>
<body class="bg-[#FFFFF0] min-h-screen flex flex-col font-sans">
    <div id="app"></div>
    <script>
        const products = ${productsStr};
        const elderlyProducts = ${elderlyStr};
        const carProducts = ${carsStr};

        const icons = {
            home: \`<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>\`,
            heart: \`<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>\`,
            shield: \`<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/></svg>\`,
            car: \`<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2"/><circle cx="7" cy="17" r="2"/><path d="M9 17h6"/><circle cx="17" cy="17" r="2"/></svg>\`,
            download: \`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/></svg>\`,
            share: \`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" x2="15.42" y1="13.51" y2="17.49"/><line x1="15.41" x2="8.59" y1="6.51" y2="10.49"/></svg>\`,
            shoppingCart: \`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="8" cy="21" r="1"/><circle cx="19" cy="21" r="1"/><path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"/></svg>\`,
            check: \`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/></svg>\`,
            upload: \`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" x2="12" y1="3" y2="15"/></svg>\`,
            x: \`<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>\`
        };

        let activeTab = 'home';
        let productImages = {};

        function chunkArray(arr, size) {
            const chunked = [];
            for (let i = 0; i < arr.length; i += size) {
                chunked.push(arr.slice(i, i + size));
            }
            return chunked;
        }

        function handleImageUpload(id, input) {
            const file = input.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = (e) => {
                    productImages[id] = e.target.result;
                    render();
                };
                reader.readAsDataURL(file);
            }
        }

        function exportPDF() {
            window.print();
        }

        function exportHTML() {
            const documentClone = document.documentElement.cloneNode(true);
            const noPrintElements = documentClone.querySelectorAll('.print\\\\:hidden');
            noPrintElements.forEach(el => el.remove());

            const htmlContent = \`<!DOCTYPE html>\\n\` + documentClone.outerHTML;
            const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'CH-FILTER-Magazine.html';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        }

        function share() {
            if (navigator.share) {
                navigator.share({
                    title: 'مجلة الصحة والتوافق الزوجي',
                    text: 'دليلك لاختيارات آمنة، مبتكرة، ومثبتة الفعالية',
                    url: window.location.href,
                }).catch(console.error);
            } else {
                alert('عذراً، متصفحك لا يدعم خاصية المشاركة المباشرة.');
            }
        }

        function setTab(tab) {
            if (tab === 'health') {
                document.getElementById('passwordModal').style.display = 'flex';
            } else {
                activeTab = tab;
                render();
            }
        }

        function submitPassword(e) {
            e.preventDefault();
            const val = document.getElementById('passwordInput').value;
            if (val === '*12*') {
                activeTab = 'health';
                closePasswordModal();
                render();
            } else {
                document.getElementById('passwordError').style.display = 'block';
                document.getElementById('passwordInput').classList.add('border-rose-500');
            }
        }

        function closePasswordModal() {
            document.getElementById('passwordModal').style.display = 'none';
            document.getElementById('passwordInput').value = '';
            document.getElementById('passwordError').style.display = 'none';
            document.getElementById('passwordInput').classList.remove('border-rose-500');
        }

        function renderMagazinePages(items, type) {
            const pages = chunkArray(items, 4);
            let html = '';
            
            pages.forEach((pageProducts, pageIndex) => {
                let productsHtml = '';
                pageProducts.forEach(product => {
                    const imgSrc = productImages[product.id] || product.image;
                    productsHtml += \`
                        <div class="group flex flex-col bg-white rounded-3xl p-6 shadow-sm border border-slate-100 relative hover:shadow-xl transition-all duration-300">
                            <div class="absolute top-8 right-8 z-20 print:hidden opacity-0 group-hover:opacity-100 transition-opacity">
                                <label class="cursor-pointer bg-white/90 p-2.5 rounded-full shadow-md hover:bg-[#F3F4F6] transition-colors border border-slate-200 flex items-center justify-center">
                                    <input type="file" class="hidden" accept="image/*" onchange="handleImageUpload(\${product.id}, this)" />
                                    <span class="text-[#0A192F]">\${icons.upload}</span>
                                </label>
                            </div>
                            <div class="w-full aspect-[4/3] overflow-hidden bg-[#F3F4F6] rounded-2xl relative mb-6">
                                <img src="\${imgSrc}" alt="\${product.name}" class="absolute inset-0 w-full h-full object-cover mix-blend-multiply transition-transform duration-700 group-hover:scale-105" />
                                <button class="absolute top-4 left-4 p-2.5 bg-white/80 backdrop-blur rounded-full text-slate-400 hover:text-rose-500 transition-colors shadow-sm">
                                    <span class="text-rose-500">\${icons.heart}</span>
                                </button>
                            </div>
                            <div class="px-2 pb-2 text-right flex flex-col flex-1">
                                <h3 class="text-xl font-bold text-[#0A192F] mb-3 line-clamp-2 leading-snug" style="font-family: serif;">\${product.name}</h3>
                                <p class="text-sm text-slate-500 line-clamp-2 mb-6 leading-relaxed flex-1">\${product.desc}</p>
                                
                                <div class="flex flex-col gap-4 mt-auto pt-4 border-t border-slate-50">
                                    <div class="flex items-center justify-between flex-row-reverse">
                                        <div class="flex items-center gap-1.5 bg-slate-50 px-3 py-1.5 rounded-full">
                                            <span class="text-emerald-500">\${icons.check}</span>
                                            <span class="text-xs font-bold text-slate-600">ينصح به</span>
                                        </div>
                                    </div>
                                    
                                    <a href="\${product.link}" target="_blank" rel="noopener noreferrer" class="w-full bg-[#0A192F] text-white py-3.5 rounded-xl flex items-center justify-center gap-2 hover:bg-[#1a2d52] transition-colors shadow-sm group/btn print:hidden">
                                        <span class="font-bold">شراء المنتج</span>
                                        <span class="group-hover/btn:scale-110 transition-transform">\${icons.shoppingCart}</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    \`;
                });

                let headerHtml = '';
                if (pageIndex === 0) {
                    let title = type === 'health' ? 'المنتجات المختارة' : type === 'elderly' ? 'منتجات بر الوالدين' : 'قسم سيارات مهمة';
                    let noticeHtml = '';
                    if (type === 'health') {
                        noticeHtml = \`
                            <div class="bg-white border-2 border-rose-100 rounded-2xl p-6 shadow-sm mb-8 text-right text-[#0A192F]">
                                <h3 class="text-xl font-bold mb-4 text-rose-700 flex items-center gap-2">
                                    <span>📌</span> تنبيهات وملاحظات هامة قبل الطلب
                                </h3>
                                <p class="mb-4 text-slate-600 font-medium">عزيزنا العميل، يرجى مراجعة النقاط التالية بعناية لضمان تجربة تسوق وشحن سلسة وناجحة:</p>
                                <ul class="space-y-4 text-slate-700">
                                    <li class="flex gap-3">
                                        <span class="text-xl">📦</span>
                                        <div>
                                            <strong class="block text-rose-800 mb-1">خيار التغليف والشحن:</strong>
                                            لضمان وصول الشحنة بنجاح وبدون معوقات إلى بعض الدول، قد يلزمك تفعيل خيار (تغليف كهدية) عند إتمام الطلب، بتكلفة إضافية قدرها 3.99 دولار.
                                        </div>
                                    </li>
                                    <li class="flex gap-3">
                                        <span class="text-xl">⚖️</span>
                                        <div>
                                            <strong class="block text-rose-800 mb-1">الأنظمة والقوانين المحلية:</strong>
                                            يرجى التأكد من أن المنتج مسموح باستيراده واستخدامه بالكامل وفقاً للأنظمة والقوانين السارية في دولتك قبل الشراء.
                                        </div>
                                    </li>
                                    <li class="flex gap-3">
                                        <span class="text-xl">💡</span>
                                        <div>
                                            <strong class="block text-rose-800 mb-1">نصيحة للاستخدام الأمثل:</strong>
                                            لضمان أعلى درجات الراحة والحفاظ على جودة مادة السيليكون، يُنصح بشدة باستخدام مزلق مائي متوافق معها تماماً أثناء الاستخدام.
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        \`;
                    }

                    headerHtml = \`
                        <div class="mb-10 avoid-page-break">
                            <div class="text-center mb-8">
                                <h2 class="text-3xl md:text-4xl font-black text-[#0A192F] mb-4 tracking-wide uppercase" style="font-family: serif;">\${title}</h2>
                                <div class="h-px bg-[#D4AF37] w-24 mx-auto mb-4"></div>
                            </div>
                            \${noticeHtml}
                        </div>
                    \`;
                }

                html += \`
                    <section class="py-12 px-6 bg-[#FFFFF0] force-page-break border-b border-slate-200 flex flex-col justify-center" style="min-height: 29.7cm;">
                        <div class="max-w-[1000px] w-full mx-auto flex flex-col h-full">
                            \${headerHtml}
                            <div class="flex-1 flex flex-col justify-center">
                                <div class="grid grid-cols-1 \${pageProducts.length === 3 ? 'md:grid-cols-3' : 'md:grid-cols-2'} gap-8 avoid-page-break">
                                    \${productsHtml}
                                </div>
                            </div>
                        </div>
                    </section>
                \`;
            });

            return html;
        }

        window.render = function() {
            const app = document.getElementById('app');
            let content = '';

            // Header (Nav)
            content += \`
                <nav class="bg-white/80 backdrop-blur-md sticky top-0 z-50 border-b border-slate-200 shadow-sm print:hidden">
                    <div class="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
                        <div class="font-serif font-black text-2xl text-[#0A192F] tracking-widest" dir="ltr">
                            CH-FILTER
                        </div>
                        <div class="flex items-center gap-3">
                            <button onclick="setTab('home')" class="flex items-center gap-2 px-5 py-2.5 rounded-full font-bold transition-all \${activeTab === 'home' ? 'bg-[#0A192F] text-white shadow-lg' : 'text-slate-700 bg-white hover:bg-slate-50 border border-slate-200'}">
                                \${icons.home} <span>الرئيسية</span>
                            </button>
                            <button onclick="setTab('health')" class="flex items-center gap-2 px-5 py-2.5 rounded-full font-bold transition-all border-2 \${activeTab === 'health' ? 'bg-rose-500 text-white border-rose-500 shadow-rose-200 shadow-lg' : 'bg-rose-50 text-rose-700 border-rose-200 hover:bg-rose-100'}">
                                <span class="\${activeTab === 'health' ? 'text-white' : 'text-rose-500'}">\${icons.heart}</span> <span>الصحة والتوافق</span>
                            </button>
                            <button onclick="setTab('elderly')" class="flex items-center gap-2 px-5 py-2.5 rounded-full font-bold transition-all border-2 \${activeTab === 'elderly' ? 'bg-emerald-600 text-white border-emerald-600 shadow-emerald-200 shadow-lg' : 'bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100'}">
                                <span class="\${activeTab === 'elderly' ? 'text-white' : 'text-emerald-600'}">\${icons.shield}</span> <span>بر الوالدين</span>
                            </button>
                            <button onclick="setTab('cars')" class="flex items-center gap-2 px-5 py-2.5 rounded-full font-bold transition-all border-2 \${activeTab === 'cars' ? 'bg-blue-600 text-white border-blue-600 shadow-blue-200 shadow-lg' : 'bg-blue-50 text-blue-800 border-blue-200 hover:bg-blue-100'}">
                                <span class="\${activeTab === 'cars' ? 'text-white' : 'text-blue-600'}">\${icons.car}</span> <span>قسم سيارات</span>
                            </button>
                        </div>
                    </div>
                </nav>
            \`;

            // Password Modal
            content += \`
                <div id="passwordModal" class="fixed inset-0 z-[100] items-center justify-center p-4 sm:p-6 bg-[#0A192F]/60 backdrop-blur-xl print:hidden" style="display: none;" onclick="closePasswordModal()">
                    <div class="bg-white rounded-3xl w-full max-w-md p-8 shadow-2xl relative text-center" onclick="event.stopPropagation()" dir="rtl">
                        <button onclick="closePasswordModal()" class="absolute top-4 left-4 p-2 rounded-full hover:bg-slate-100 transition-colors">
                            <span class="text-slate-500">\${icons.x}</span>
                        </button>
                        <div class="w-16 h-16 bg-[#F3F4F6] rounded-full flex items-center justify-center mx-auto mb-6">
                            <span class="text-[#D4AF37] scale-150">\${icons.heart}</span>
                        </div>
                        <h3 class="font-bold text-2xl text-[#0A192F] mb-2" style="font-family: serif;">قسم الصحة والتوافق الزوجي</h3>
                        <p class="text-slate-500 mb-8">الرجاء إدخال الرقم السري للوصول إلى هذا القسم.</p>
                        <form onsubmit="submitPassword(event)" class="flex flex-col gap-4">
                            <div>
                                <input type="password" id="passwordInput" placeholder="الرقم السري" oninput="document.getElementById('passwordError').style.display = 'none'; this.classList.remove('border-rose-500')" class="w-full px-5 py-4 bg-[#F3F4F6] rounded-xl border border-transparent focus:border-[#D4AF37] outline-none transition-all text-center text-xl tracking-widest" autofocus />
                                <p id="passwordError" class="text-rose-500 text-sm mt-2 font-medium" style="display: none;">الرقم السري غير صحيح</p>
                            </div>
                            <button type="submit" class="w-full bg-[#0A192F] text-white py-4 rounded-xl font-bold hover:bg-[#1a2d52] transition-colors mt-2 text-lg">دخول</button>
                        </form>
                    </div>
                </div>
            \`;

            if (activeTab === 'home') {
                content += \`
                    <div class="flex-1 flex flex-col bg-[#FFFFF0] print:hidden">
                        <header class="relative bg-[#0A192F] text-white overflow-hidden py-24 px-6 rounded-b-[3rem] shadow-xl">
                            <div class="absolute inset-0 opacity-10 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-white via-transparent to-transparent"></div>
                            <div class="max-w-4xl mx-auto text-center relative z-10">
                                <h1 class="text-5xl md:text-7xl font-black mb-8 leading-tight tracking-tight" style="font-family: serif;">مجلة الصحة<br/><span class="text-[#D4AF37]">والتوافق الزوجي</span></h1>
                                <p class="text-xl md:text-2xl text-slate-300 mb-12 max-w-2xl mx-auto leading-relaxed">دليلك الموثوق لاختيارات آمنة، مبتكرة، ومثبتة الفعالية لحياة أكثر راحة وسعادة.</p>
                                <button onclick="setTab('health')" class="bg-[#D4AF37] text-white px-10 py-5 rounded-full font-bold text-xl hover:bg-amber-400 hover:scale-105 transition-all shadow-xl shadow-amber-900/20">تصفح المجلة الآن</button>
                            </div>
                        </header>
                        <section class="py-24 px-6 max-w-5xl mx-auto w-full text-center">
                            <h2 class="text-3xl font-black text-[#0A192F] mb-12" style="font-family: serif;">لماذا تختار منتجاتنا؟</h2>
                            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                                <div class="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 flex flex-col items-center">
                                    <div class="w-16 h-16 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center mb-6 scale-150">\${icons.shield}</div>
                                    <h3 class="text-xl font-bold text-[#0A192F] mb-4">جودة موثوقة</h3>
                                    <p class="text-slate-500 leading-relaxed">جميع المنتجات مختارة بعناية فائقة لضمان أعلى معايير الجودة والأمان.</p>
                                </div>
                                <div class="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 flex flex-col items-center">
                                    <div class="w-16 h-16 bg-amber-50 text-amber-600 rounded-full flex items-center justify-center mb-6 scale-150">\${icons.heart}</div>
                                    <h3 class="text-xl font-bold text-[#0A192F] mb-4">تصميم مريح</h3>
                                    <p class="text-slate-500 leading-relaxed">نركز على المنتجات التي توفر أقصى درجات الراحة وسهولة الاستخدام.</p>
                                </div>
                                <div class="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 flex flex-col items-center">
                                    <div class="w-16 h-16 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mb-6 scale-150">\${icons.check}</div>
                                    <h3 class="text-xl font-bold text-[#0A192F] mb-4">نتائج مضمونة</h3>
                                    <p class="text-slate-500 leading-relaxed">خيارات مجربة ومثبتة الفعالية لتحسين جودة حياتك اليومية.</p>
                                </div>
                            </div>
                        </section>
                    </div>
                \`;
            } else {
                let items = [];
                if (activeTab === 'health') items = products;
                if (activeTab === 'elderly') items = elderlyProducts;
                if (activeTab === 'cars') items = carProducts;
                
                content += renderMagazinePages(items, activeTab);

                content += \`
                    <div class="w-full bg-[#0A192F] px-6 py-6 flex flex-col sm:flex-row items-center justify-center gap-6 print:hidden">
                        <button onclick="exportPDF()" class="w-full sm:w-auto bg-[#D4AF37] text-white px-10 py-4 rounded-full shadow-lg hover:bg-amber-400 hover:scale-105 transition-all flex items-center justify-center gap-4 font-bold text-lg" title="تصدير المجلة كملف PDF عالي الجودة">
                            \${icons.download} <span>Export (PDF)</span>
                        </button>
                        <button onclick="exportHTML()" class="w-full sm:w-auto bg-emerald-600 text-white px-10 py-4 rounded-full shadow-lg hover:bg-emerald-500 hover:scale-105 transition-all flex items-center justify-center gap-4 font-bold text-lg" title="تصدير المجلة كملف HTML كامل يعمل بدون إنترنت">
                            \${icons.download} <span>Export (HTML)</span>
                        </button>
                        <button onclick="share()" class="w-full sm:w-auto bg-white text-[#0A192F] px-10 py-4 rounded-full shadow-lg border border-slate-200 hover:bg-slate-50 hover:scale-105 transition-all flex items-center justify-center gap-4 font-bold text-lg">
                            \${icons.share} <span>Share</span>
                        </button>
                    </div>
                \`;
            }

            content += \`
                <footer class="bg-white py-16 px-6 border-t border-slate-200 text-center avoid-page-break mt-auto">
                    <p class="text-slate-500 text-lg md:text-xl font-medium mb-4">CH-Filter © 2026. جميع الحقوق محفوظة.</p>
                    <p class="text-slate-400 text-sm md:text-base max-w-xl mx-auto leading-relaxed">
                        نحن نلتزم باختيار المنتجات الأفضل لك. قد نربح عمولة عند التسوق عبر الروابط المذكورة في المجلة.
                    </p>
                </footer>
            \`;

            app.innerHTML = content;
        }

        window.render();
    </script>
</body>
</html>\`;

fs.writeFileSync('/app/applet/dist/vanilla.html', html);
