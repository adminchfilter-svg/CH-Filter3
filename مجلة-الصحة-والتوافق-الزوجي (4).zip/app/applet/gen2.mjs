import fs from 'fs';
import https from 'https';

async function fetchImageBase64(url) {
    if (!url || !url.startsWith('http')) return url;
    return new Promise((resolve) => {
        https.get(url, (res) => {
            if (res.statusCode !== 200) {
                resolve(url);
                return;
            }
            const chunks = [];
            res.on('data', (chunk) => chunks.push(chunk));
            res.on('end', () => {
                const buffer = Buffer.concat(chunks);
                const type = res.headers['content-type'] || 'image/jpeg';
                resolve(`data:${type};base64,${buffer.toString('base64')}`);
            });
        }).on('error', () => {
            resolve(url);
        });
    });
}

const encryptProducts = (products, key) => {
    const text = encodeURIComponent(JSON.stringify(products));
    let result = '';
    for (let i = 0; i < text.length; i++) {
        result += String.fromCharCode(text.charCodeAt(i) ^ key.charCodeAt(i % key.length));
    }
    return Buffer.from(result).toString('base64');
};

async function main() {
    const { elderlyProducts, carProducts, healthProducts } = await import('./fix_arrays.mjs').catch(() => {
        return { elderlyProducts: [], carProducts: [], healthProducts: [] };
    });

    for (const p of healthProducts) {
        if (!p.image && p.link === "https://s.click.aliexpress.com/e/_oolm7QJ") p.image = "https://ae01.alicdn.com/kf/S8f96e8dd12174d81a94254ec9945037dK.jpg";
        if (!p.image && p.link === "https://s.click.aliexpress.com/e/_olN9X2R") p.image = "https://ae01.alicdn.com/kf/Sf5f159ab38b8433d9c22e4c4efd46487W.jpg";
        if (!p.image && p.link === "https://s.click.aliexpress.com/e/_oDIW2N1") p.image = "https://ae01.alicdn.com/kf/S91f16da88656461c94d0c159074d27572.jpg";
    }
    
    console.log("Fetching images...");
    for (const p of healthProducts) p.image = await fetchImageBase64(p.image);
    for (const p of elderlyProducts) p.image = await fetchImageBase64(p.image);
    for (const p of carProducts) p.image = await fetchImageBase64(p.image);

    const newEncrypted = encryptProducts(healthProducts, "*12*");

    const templateHtml = fs.readFileSync('build-html.mjs', 'utf8');
    
    let htmlContentString = templateHtml.split('export const htmlContent = `')[1].split('`;')[0];
    
    // Replace ${JSON.stringify...} with actual data
    htmlContentString = htmlContentString.replace('${newEncrypted}', newEncrypted);
    htmlContentString = htmlContentString.replace('${JSON.stringify(elderlyProducts)}', JSON.stringify(elderlyProducts));
    htmlContentString = htmlContentString.replace('${JSON.stringify(carProducts)}', JSON.stringify(carProducts));

    // Handle string replacement correctly for other placeholders if any
    
    fs.writeFileSync('standalone.html', htmlContentString);
    console.log("Written to standalone.html");
}

main().catch(console.error);
