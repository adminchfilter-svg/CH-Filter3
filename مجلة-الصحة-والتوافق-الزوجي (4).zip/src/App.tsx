import React from 'react';
import { get, set } from 'idb-keyval';
import html2pdf from 'html2pdf.js';
import { 
  Heart, 
  TriangleAlert, 
  Sparkles, 
  CircleCheck, 
  ShieldCheck, 
  Star, 
  ArrowLeft,
  Upload,
  Download,
  Share2,
  X,
  Plus,
  Home,
  ShoppingCart,
  Car
} from 'lucide-react';


const encryptedProducts = "DwRwDx1zFxgYWFYPGAMXGWsAFxhpFAAYRFBfTw8DAA8ZcBcYGBR2Ew8JCg9uCRdrHRR2Ew8JAA9uCBcSaxQAGg91Cg9oAhduExQKaw91Cw8SBRduExQKaw91Cw8SAhduExQKEg91Cw8SBxcYGhR2Eg9zBQ9uCRdrEhR2Ew8Jcw8YARduEhRwGQ91Cw8SBBduExQKaw91Cw8SAhcYGBQAaQ8DAEZDX1kPGAMXGWsUABhCRUZaWRQBaw8DdA8Yd1NHUF8cXkUUAGweUF1QXWJhDxl3RktNFAFuS19ZQBkDAgcYARcYGBQAaQ8DAENHUFVPDwMADxlwFxgYWUZeWkIXGWsUAGwPA3RDR1BVT1kfR0RZQV5LWVkcSUVcFxhsQVpFXl4fGx8JBhkaCQQcHAYGHgcDBk4fUgYdHlcAS08UAWxbFAFuEgEXGBxGFxluCQIaDwMES19FXQ8ZdVRFWFxTXg8DBExDRRcZblJARVoUABgPA3EPGANWT1lSFxgYFAFrDwMAD24IFxISFHYSD3AFD24IFxIYFHYTDwlzDxgBF24SFHAZD3ULDxJwF24TFAoeD3ULDxJwF24TFAoZD3ULDxIJF24TFAocDwMCD24JF2gdFHYSD3AKD24IFxJrFAAaD3UKD2gCF24TFAofD3ULDxJwF24TFAoZDwMCD24IFxJrFHYTDwkHD24IFxIcFHYSD3B2DxgBF24SFHMfD3UKD2t1F24SFHAZD3UKD2sGF24SFHAZD3ULDxJzF24SFHMdDwMCD24JF2sZFHYTDwkBD24JF2sSFHYSD3MDDxgBF24SFHMSD3UKD2sGF24TFAoeD3UKD2sGF24TFAofD3UKD2twF24TFAoeD3UKD2sGF24SFHMbD3UKDxJyFxgaFHYTDwkKD24IFxJrFHYSD3MED24IFxJrFHYTDwkDDxgBF24SFHNrD3UKD2tyF24SFHAbD3UKD2sJF24SFHMTDwMCD24IFxIfFHYSD3B3D24JF2trFHYTDwkGD24IFxIbFHYSD3ALDxgBF24TFAofD3UKD2gIFxgaFHYSD3BwD24JF2sSFHYSD3AFD24JF2trFAAaD3UKD2tyF24TFAprD3UKD2t3FxgaFHYTDwkKD24JF2gZFHYTDwkFD24IFxISFHYTDwkGD24JF2sTFAAaD3ULDxIAF24TFAprDwMCD24JF2sdFHYTDwkGD24JF2sdFHYSD3MBD24JF2trFHYSD3B3D24JF2tsFHYSD3AFD24IFxIfFAAaD3ULDxIJF24SFHMdD3ULDxIFF24SFHNrD3ULDxIHF24SFHASD3ULDxJwF24TFAobBBQAGA8Gdg8YchcdaBQAGENVFxgYFAFrGBQAaQ8DAERLXFcPGAMXGWsUABgPdQsPEgkXbhIUcx0PdQsPEgMXbhMUCmsPAwIPbgkXaBkUdhMPCXMPbggXEh4UdhMPCXMPbggXEhkUdhMPCQoPbggXEhwUABoPdQsPEgQXbhIUc24PdQsPEgAXbhIUcBgPAwIPbgkXaxIUdhIPcAUPbgkXaBsUdhIPcwAPGAMXGGkUABhGWFxBDwMADxlwFxgYWUZeWkIXGWsUAGwPA3RLR0tcBF5eFxhsBVNyclAKcA8CdF5LVhcZblBcQUACABoHAwIPGAMXGGkUABhDXFNNTxQAGA8Ccw8YA1peXkFBDxlwFxhsFABsQ1xTTU9CHF9EQkJGS0JaBEleXw8Yd0JCRUVdBxsEAxIcAAYTGgELGxIcBBkTBFAaSFUKGBhTFxlsQBcZbgkCDxgHRQ8ZdQoaGhQAHEtERkUPAnZMRUNfS14UABxMWEYPGXVRWEVBFxgYFABpDwMATk9CUQ8YAxcZaxQAGA91Cw8SCRduEhRzHQ91Cw8SAxduExQKaw8DAg9uCRdoGRR2Ew8Jcw9uCBcSHhR2Ew8Jcw9uCBcSGRR2Ew8JCg9uCBcSHBQAGg91Cg9rCRduEhRzaw91Cg9oBBduExQKHw91Cw8ScBduExQKHw8DAg9uCRdrEhR2Eg9wBQ9uCRdoGxR2Eg9zAA8YARduExQKEg91Cw8SBBduExQKHg91Cw8SBBduEhRwGQ8DAg9uCBcSHxR2Eg9wdg9uCBcSGxR2Eg9zAA8YARduExQKaw91Cg9oAhduEhRzHQ91Cg9oCBduEhRzbA8DAg9uCRdoExR2Ew8JBg9uCBcSExQAGg91Cg9rBBduEhRwHA91Cg9rBhduExQKGw91Cg9rCBcYGhR2Eg9wBQ9uCBcSHhR2Eg9wcw9uCBcSHBR2Ew8JCg9uCRdoExQAGg91Cw8SBRduExQKHg91Cg9oCBduExQKHg91Cg9rBhduExQKGA91Cg9rCBcYGhR2Eg9wBQ9uCBcSHhR2Eg9zAA9uCBcSEhR2Eg9wcQ9uCBcSaxR2Eg9wCw9uCRcSaRQAGg91Cw8SBBduEhRwEw8DAg9uCRdrbxR2Eg9wBQ9uCBcSHxR2Eg9wCw8YARduExQKHw91Cg9oABduExQKHA91Cg9rCBcYGhR2Ew8JCg9uCBcSHxR2Eg9zAw9uCBcSaxR2Eg9wdg9uCRdrExQAGg91Cw8SCRduEhRzGA91Cw8SBBduExQKHA91Cg9rCBcYGhR2Eg9zCw9uCBcSHhR2Ew8JCw8YARduEhRzHQ91Cw8SBRduEhRzEg91Cg9oBRduEhRwGw91Cg9rCBwPGAMXHW4UAGkPBnAPGANbTg8DAA8ZcAEPGHIXGBhfU0dPFAAYDwJzDxgDF24TFAoSD3UKD2sGF24TFAoYD3ULDxJwFxgaFHYSD3MBD24IFxJrFHYTDwkGD24IFxJrFHYTDwkBD24IFxISFHYTDwkEDxgBF24TFAofD3UKD2gAF24TFAocDwMCD24IFxISFHYTDwkHD24JF2gbFHYTDwlzD24JF2tuFAAYDwNxDxgDXkNEWhcYGBQBaw8DAEJeRUJZDwJzDxh3FxhsUF9QRB9GRQ8DdB4eAQcZYlwXGWxFU00PAnZLRFpYGRgBHxgaFAAYDwNxDxgDW0dLVlcPGAMXGWsUABhCRUZaWRQBaw8DdA8Yd1tHS1ZXWQREXFlaXVNZQh9RRUcUAGxaWV1eRRwDHxsEAR0dCAIfHQEBB0kFBRISVAcbS1cDHw8CdFsPAnYSGhQAHF0UAW4SAQIPGAdTX15eFxluV11YR1BGDxgHVENeFAFuSUNdWg8DAA8YchcYGFVXWUkUABgPAnMPGAMXbhMUChIPdQoPawYXbhMUChgPdQsPEnAXGBoUdhIPcwEPbggXEmsUdhMPCQYPbggXEmsUdhMPCQEPbggXEhIUdhMPCQQPGAEXbhMUCh8PdQoPaAAXbhMUChwPAwIPbggXEmsUdhMPCQcPbggXEhwUdhIPcHYPGAEXbhIUcx8PdQoPa3UXbhIUcBkPdQoPawYXbhIUcBkPdQsPEnMXbhIUcx0PAwIPbgkXaxkUdhMPCQEPbgkXaxIUdhIPcwMPGAEXbhIUcxkPdQoPa3MXbhMUChwPdQoPawYXbhIUcxsPAwIPbgkXax0UdhMPCQYPbgkXax0UdhIPcwEPbgkXa2sUdhIPcHcPbgkXa2wUdhIPcAUPbggXEh8UdhIPCXEPGAEXbhMUCh8PdQoPaAgXGBoUdhIPcHAPbgkXaxIUdhIPcAUPbgkXa2sUABoPdQsPEgQXbhIUcBsPdQsPEnAXbhIUc24PAwIPbggXEhIUdhIPcHcPbgkXax0UdhMPCQcPbgkXaxMUABoPdQoPaAIXbhMUCmsPdQsPEgUXbhMUCmsPdQsPEgIXbhMUChIPdQsPEgcXGBoUdhIPcwUPbgkXaxIUdhMPCXMPbgkXaxMUABoPdQsPEgMXbhIUcx0PdQoPawkXbhMUCh4PdQoPawgXGBoUdhMPCQYPbggXEh4UdhIPc3MPbgkXaBkUdhMPCQYPGAEXbhMUChIPdQoPawQXbhIUcBMPdQoPawYXbhIUc2wPdQoPawgXGBoUdhIPcAUPbggXEh4UdhIPcAUPbgkXaBkUdhIPcHMPbgkXa28UdhIPcHQPbgkXax0UdhMPCQcEDwMADx11FxhpFAVoDwMAQ04UABgPAnMeDwNxDxgDXEtHVBcYGBQBaw8DAA9uCBcSEhR2Eg9wBQ9uCBcSGBR2Ew8Jcw8YARduEhRwGQ91Cw8ScBduExQKHg91Cw8ScBduExQKGQ91Cw8SCRduExQKHA8DAg9uCRdoExR2Eg9zAw9uCBcSaxR2Eg9zBA8YAxcYaRQAGEZYXEEPAwAPGXAXGBhZRl5aQhcZaxQAbA8DdEtHS1wEXl4XGGwFBhofAnpHDwJ0XktWFxluUFxBQAIAGgcDAg8YAxcYaRQAGENcU01PFAAYDwJzDxgDWl5eQUEPGXAXGGwUAGxDXFNNT0IcX0RCQkZLQloESV5fDxh3QkJFRV0HGwcDHB4BAx0SBQoeHxwDEhoJChhIUAtISwkXGWxAFxluCQIPGAdFDxl1ChoaFAAcS0RGRQ8CdkxFQ19LXhQAHExYRg8ZdVFYRUEXGBgUAGkPAwBOT0JRDxgDFxlrFAAYD3ULDxIJF24SFHMdD3ULDxIDF24TFAprDwMCD24JF2gZFHYTDwlzD24IFxIeFHYTDwlzD24IFxIZFHYTDwkKD24IFxIcFAAaD3UKD2gIF24SFHAbD3ULDxJwF24SFHAcDwMCD24IFxJrFHYTDwkHD24IFxIcFHYSD3B2DxgBF24SFHMfD3UKD2t1F24SFHAZD3UKD2sGF24SFHAZD3ULDxJzF24SFHMdDwMCD24JF2sSFHYSD3AFD24IFxIeFHYSD3AFD24IFxIfFHYSD3BzD24IFxIeFHYSD3AFD24JF2sbFAAaD3ULDxIJF24TFAprD3UKD2gHF24TFAprD3ULDxIAFxgaFHYTDwkGD24IFxIfFHYSD3MBD24JF2sTFAAaD3UKD2tyF24SFHNsD3ULDxJwF24SFHNsD3UKD2sIFxgaFHYTDwkGD24IFxIeFHYSD3MLD24IFxIeFHYSD3AFD24IFxIYFHYSD3ALDxgBF24SFHMdD3ULDxIFF24SFHAYD3ULDxIJF24SFHNpD3ULDxJwF24SFHMTD3UKDxJyFxgaFHYTDwkHD24JF2gTFAAaD3UKD2twF24SFHAfD3ULDxIEF24TFAprD3ULDxIEFxgaFHYSD3MLD24IFxIfFHYTDwkGD24IFxJrFAAaD3ULDxIJF24SFHAZD3ULDxIGF24TFAoeDwMCD24JF2sdFHYTDwkGD24JF2sdFHYSD3MDD24JF2trFHYSD3B0D24JF2sdFHYSD3ADBA8DAA8ddRcYaRQFaA8DAENOFAAYDwJzHw8DcQ8YA1xLR1QXGBgUAWsPAwAPbggXEhIUdhIPcAUPbggXEhgUdhMPCXMPGAEXbhIUcBkPdQsPEnAXbhMUCh4PdQsPEnAXbhMUChkPdQsPEgkXbhMUChwPAwIPbggXEh8UdhIPcHMPbgkXaBMUdhIPcHQPbgkXa2wUABoPdQoPawYXbhMUCh4PdQsPEgQXbhMUChgPdQoPawYXbhIUcBkPdQoPawYXbhIUc2sPAwAPGHIXGBhdW0RBFAAYDwJzDxgDWl5eQUEPGXAXGGwUAGxLXEhEBEVdDxh3Bl0TYV14aRQBbF5QVQ8ZdVNEQVsBGBocABoPAwAPGHIXGBhYX0tNVBcYGBQBaw8DAEJeRUJZDwJzDxh3FxhsWF9LTVRBBF9fQVpGUEFCBFJdRw8DdFpCXkZFBwAHHRwBCxgdBwAdEwAfTk4IVxgYAwJJS1UDDxl3Qw8ZdQoaDwMEXQ8CdhIaARcYHFBHXkUUAW5MXkBHS0UXGBxXW14PAnZJWF5CDxgDFxhpFAAYTlRBSQ8DAA8ZcBcYGBR2Ew8JCg9uCRdrHRR2Ew8JAA9uCBcSaxQAGg91Cg9oAhduExQKaw91Cw8SBRduExQKaw91Cw8SAhduExQKEg91Cw8SBxcYGhR2Eg9wCg9uCBcSHxR2Ew8JAA9uCRdrHRR2Eg9zAQ8YARduExQKHw91Cg9rdBduEhRzaw91Cw8SBRduExQKGw8DAg9uCBcSaxR2Ew8JBA9uCRdrHRR2Eg9zAQ9uCRdrEhQAGg91Cg9rBhduEhRzbg91Cg9rcBduExQKaw91Cg9rBhduEhRzaQ91Cg9rBhduEhRzaw8DAg9uCBcSHxR2Eg9wcw9uCRdoExR2Eg9wdA9uCRdrbBR2Eg9wCw9uCRcSaRQAGg91Cw8SBBduEhRwHw91Cw8SBxduExQKEg91Cg9oCBcYGhR2Ew8JBw9uCBcSHBQAGg91Cg9rdBduEhRzHQ91Cw8SBBduEhRzHQ91Cg9rcBcYGhR2Ew8JBw9uCRdoGxR2Ew8JBA9uCRdrExQAGg91Cg9rcBduExQKEg91Cw8SABduEhRwGw8DAg9uCRdrHRR2Ew8JBg9uCRdoGxR2Eg9wBQ9uCRdrbhR2Eg9wCw8YARduExQKEg91Cg9rBhduExQKHg91Cg9rcxduEhRzEg91Cg9rBhduEhRzaw8DAg9uCRdrGRR2Eg9wcA9uCBcSHBR2Eg9wBQ9uCRdrGxQAGg91Cg9rBhduExQKHg91Cg9rBhduEhRwGQ91Cg9rcBduEhRzbw91Cg9rdxduEhRzHQ91Cw8SBBwPGAMXHW4UAGkPBnAPGANbTg8DAA8ZcAQPGHIXGBhfU0dPFAAYDwJzDxgDF24TFAoSD3UKD2sGF24TFAoYD3ULDxJwFxgaFHYSD3MBD24IFxJrFHYTDwkGD24IFxJrFHYTDwkBD24IFxISFHYTDwkEDxgBF24SFHMSD3UKD2twF24SFHAfD3ULDxIEF24TFAprD3ULDxIEFxgaFHYTDwkKD24JF2sdFHYTDwkAD24JF2gTFHYTDwlzDxgDFxhpFAAYRlhcQQ8DAA8ZcBcYGFlGXlpCFxlrFABsDwN0S0dLXAReXhcYbAVEXngERkkPAnReS1YXGW5QXEFAAgAaBwMCDxgDFxhpFAAYQ1xTTU8UABgPAnMPGANaXl5BQQ8ZcBcYbBQAbENcU01PQhxfREJCRktCWgRJXl8PGHdCQkVFXQcbBAEeGgEKEhMGCxMfHAAdSwMBTxIECxoeCRcZbEAXGW4JAg8YB0UPGXUKGhoUABxLREZFDwJ2TEVDX0teFAAcTFhGDxl1UVhFQRcYGBQAaQ8DAE5PQlEPGAMXGWsUABgPdQsPEgkXbhIUcx0PdQsPEgMXbhMUCmsPAwIPbgkXaBkUdhMPCXMPbggXEh4UdhMPCXMPbggXEhkUdhMPCQoPbggXEhwUABoPdQoPawkXbhIUc2sPdQoPaAQXbhMUCh8PdQsPEnAXbhMUCh8PAwIPbggXEhIUdhIPcAUPbggXEhgUdhIPcwsPbggXEmsUABoPdQsPEnAXbhMUChIPdQsPEgAXbhIUcBsPAwIPbgkXa2sUdhIPcHEPbgkXaBsUdhIPcAoPbgkXaxMUABoPdQsPEgQXbhIUc28PdQoPa3AXbhMUCh4PdQsPEgAXbhIUcxMPdQoPEnIXGBoUdhMPCQcPbgkXaBMUABoPdQoPa3QXbhIUcx0PdQsPEgQXbhIUcxMPAwIPbggXEhwUdhIPcAUPbgkXaBMUdhMPCQcPbgkXaxMUABoPdQsPEgkXbhIUcxgPdQsPEgQXbhMUChwPdQoPawgXGBoUdhMPCQoPbgkXaBkUdhMPCQUPbggXEh4UdhIPcAsPGAEXbhIUcx0PdQsPEgUXbhIUc2sPdQsPEgcXbhIUcBIPdQsPEnAXbhMUChsPAwIPbgkXaxIUdhIPcwsPbgkXa2wUABoPdQsPEgIXbhMUCh4PAwIPbgkXax0UdhIPcwEPbgkXa2sUdhIPcHcPbgkXa2wUdhIPcAUPbggXEh8fFxgYFAVuDwNxDx1zFxgYWFYPGAMXGWsGFxhpFAAYRFBfTw8DAA8ZcBcYGBR2Ew8JCg9uCRdrHRR2Ew8JAA9uCBcSaxQAGg91Cg9oAhduExQKaw91Cw8SBRduExQKaw91Cw8SAhduExQKEg91Cw8SBxcYGhR2Eg9zBg9uCBcSGxR2Eg9wBQ9uCBcSGxQAGg91Cw8SBBduExQKHA91Cw8SAxduEhRwHQ8DAA8YchcYGF1bREEUABgPAnMPGANaXl5BQQ8ZcBcYbBQAbEtcSEQERV0PGHcGT3pGYlweFAFsXlBVDxl1U0RBWwEYGhwAGg8DAA8YchcYGFhfS01UFxgYFAFrDwMAQl5FQlkPAnMPGHcXGGxYX0tNVEEEX19BWkZQQUIEUl1HDwN0WkJeRkUHAAcSGQgGHRgABxgfCB8ZElQBG0hUCh0fAFQPGXdDDxl1ChoPAwRdDwJ2EhoBFxgcUEdeRRQBbkxeQEdLRRcYHFdbXg8CdklYXkIPGAMXGGkUABhOVEFJDwMADxlwFxgYFHYTDwkKD24JF2sdFHYTDwkAD24IFxJrFAAaD3UKD2gCF24TFAprD3ULDxIFF24TFAprD3ULDxICF24TFAoSD3ULDxIHFxgaFHYSD3MGD24IFxIbFHYSD3AFD24IFxIbFAAaD3UKD2sJF24TFAocD3ULDxIDF24SFHMdD3UKD2gGFxgaFHYSD3AKD24JF2sdFHYSD3MDD24JF2gYFHYSD3ALDxgBF24TFAofD3UKD2gEF24TFAofD3ULDxIEFxgaFHYTDwkGD24JF2trFHYSD3MLD24JF2gYFHYTDwlzD24JF2gYFAAaD3UKD2sGF24TFAoeD3UKD2sEF24SFHNuD3UKD2gCF24SFHMdD3UKD2gCFxgaFHYTDwkKD24JF2sfFHYSD3MED24JF2sdFHYTDwkDD24JF2sTFAAaD3UKD2sGF24TFAoeD3UKD2twF24TFAocD3ULDxIJF24SFHATD3UKDxJyFxgaFHYTDwkHD24JF2gTFAAaD3ULDxIEF24SFHAbD3ULDxIJF24TFAocD3UKD2sIFxgaFHYSD3MLD24JF2sdFHYTDwkGD24IFxJrFHYSD3ALDxgBF24TFAoSD3UKD2gAF24SFHMdD3UKD2t1F24SFHMTDwMCD24JF2sZFHYSD3BwD24IFxIcFHYSD3AFD24JF2sbFAAaD3UKD2sGF24TFAoeD3UKD2sGF24SFHAZD3UKD2twF24SFHNvD3UKD2t3F24SFHMdD3ULDxIEHA8YAxcdbhQAaQ8GcA8YA1tODwMADxlwCg8YchcYGF9TR08UABgPAnMPGAMXbhMUChIPdQoPawYXbhMUChgPdQsPEnAXGBoUdhIPcwEPbggXEmsUdhMPCQYPbggXEmsUdhMPCQEPbggXEhIUdhMPCQQPGAEXbhIUcBkPdQsPEgQXbhMUCmsPdQsPEgIXGBoUdhMPCQcPbggXEh8UdhMPCXMPbgkXaBgUABgPA3EPGANeQ0RaFxgYFAFrDwMAQl5FQlkPAnMPGHcXGGxQX1BEH0ZFDwN0Hk9jWGxlUhcZbEVTTQ8CdktEWlgZGAEfGBoUABgPA3EPGANbR0tWVw8YAxcZaxQAGEJFRlpZFAFrDwN0Dxh3W0dLVldZBERcWVpdU1lCH1FFRxQAbFpZXV5FHAMfGwMCHBMGBRgTCAcHT1IEH09VBh9LV1YcDwJ0Ww8CdhIaFAAcXRQBbhIBAg8YB1NfXl4XGW5XXVhHUEYPGAdUQ14UAW5JQ11aDwMADxhyFxgYVVdZSRQAGA8Ccw8YAxduExQKEg91Cg9rBhduExQKGA91Cw8ScBcYGhR2Eg9zAQ9uCBcSaxR2Ew8JBg9uCBcSaxR2Ew8JAQ9uCBcSEhR2Ew8JBA8YARduEhRwGQ91Cw8SBBduExQKaw91Cw8SAhcYGhR2Eg9wCg9uCBcSHxR2Ew8JBg9uCBcSHxR2Eg9zAQ8YARduExQKHw91Cw8SBBduExQKaw91Cg9oAxcYGhR2Ew8Jcw9uCRdoGRR2Eg9wBQ9uCRdoExR2Eg9wdA8YARduEhRwEw91Cw8SBRduExQKEw8DAg9uCRdraxR2Eg9wdg9uCRdoGRR2Ew8Jcw9uCBcSHBQAGg91Cg9rBhduExQKHg91Cg9rcxduEhRzEg91Cg9rBhduEhRzaw8DAg9uCBcSEhR2Ew8Jcw9uCBcSHxR2Ew8JBA9uCRdrbhQAGg91Cg9rcBduEhRzaQ91Cg9oABduEhRzEg91Cg9rCBcYGhR2Ew8JBw9uCRdrbxR2Eg9wcw9uCBcSHhR2Ew8JAw9uCRdrExR2Eg8JcQ8YARduExQKHw91Cg9oCBcYGhR2Eg9wBw9uCBcSHxR2Ew8JAQ9uCRdrHRR2Ew8JBA9uCBcSaxR2Eg9wCw8YARduEhRzHw91Cg9oCBduEhRzHQ91Cg9rdxduEhRzEw8DAg9uCRdrHRR2Eg9zAQ9uCRdraxR2Eg9wdw9uCRdrbBR2Eg9wBQ9uCBcSHxR2Ew8JBQ8YARduExQKHw91Cg9oABduEhRzHQ91Cg9rcBcYGhR2Eg9zCw9uCRdrbBR2Ew8Jcw9uCRdrbBR2Eg9wCwQPAwAPHXUXGGkUBWgPAwBDThQAGA8CcxMPA3EPGANcS0dUFxgYFAFrDwMAD24IFxISFHYSD3AFD24IFxIYFHYTDwlzDxgBF24SFHAZD3ULDxJwF24TFAoeD3ULDxJwF24TFAoZD3ULDxIJF24TFAocDwMCD24JF2sSFHYSD3BzD24JF2gfFHYTDwkHD24IFxJrFHYTDwkHDxgBF24SFHNuD3ULDxIFF24TFAoYD3ULDxJwFxgYFABpDwMARkNfWQ8YAxcZaxQAGEJFRlpZFAFrDwN0Dxh3U0dQXxxeRRQAbB5XBEFpdUUPGXdGS00UAW5LX1lAGQMCBxgBFxgYFABpDwMAQ0dQVU8PAwAPGXAXGBhZRl5aQhcZaxQAbA8DdENHUFVPWR9HRFlBXktZWRxJRVwXGGxBWkVeXh8bHwUGGRwGBxwdHAJMGFdRSBoBC08aUxcZbEAXGW4JAg8YB0UPGXUKGhoUABxLREZFDwJ2TEVDX0teFAAcTFhGDxl1UVhFQRcYGBQAaQ8DAE5PQlEPGAMXGWsUABgPdQsPEgkXbhIUcx0PdQsPEgMXbhMUCmsPAwIPbgkXaBkUdhMPCXMPbggXEh4UdhMPCXMPbggXEhkUdhMPCQoPbggXEhwUABoPdQoPawkXbhIUc2sPdQoPaAQXbhMUCh8PdQsPEnAXbhMUCh8PAwIPbgkXa24UdhMPCQYPbggXEhgUdhMPCXMPGAEXbhMUCh8PdQoPaAAXbhMUChwPAwIPbggXEmsUdhMPCQcPbggXEhwUdhIPcHYPGAEXbhIUc2gPdQoPawkXbhIUcx0PdQoPa3AXbhMUCmgPdQoPawYXGBoUdhIPcAcPbgkXaBwUdhIPcAUPbggXEhsUdhMPCXMPbggXEmgUdhIPcAUPGAEXbhIUcxkPdQoPa3MXbhMUChwPdQoPawYXbhIUcxsPAwIPbgkXax0UdhMPCQYPbgkXax0UdhIPcwEPbgkXa2sUdhIPcHcPbgkXa2wUdhIPcAUPbggXEh8UdhIPCXEPGAEXbhMUCh8PdQoPaAQXbhMUChwPdQsPEgkXbhIUcBMPAwIPbggXEh8UdhMPCQQPGAEXbhIUc28PdQoPawYXbhMUCh8PdQoPawYXbhIUc2sPAwIPbgkXaB0UdhIPcAoPbggXEmsUdhIPcAsPGAEXbhIUcxgPdQsPEgQXbhMUChwPdQoPawgXGBoUdhMPCQoPbgkXaBkUdhMPCQUPbggXEh4UdhIPcAsPGAEXbhIUcx0PdQsPEgUXbhIUc2sPdQsPEgcXbhIUcBIPdQsPEnAXbhMUChsEFAAYDwZ2DxhyFx1oFAAYQ1UXGBgUAWsbARcYaRQAGERQX08PAwAPGXAXGBgUdhMPCQoPbgkXax0UdhMPCQAPbggXEmsUABoPdQoPaAIXbhMUCmsPdQsPEgUXbhMUCmsPdQsPEgIXbhMUChIPdQsPEgcXGBoUdhIPcAoPbggXEh4UdhMPCQoPbggXEhwUABoPdQoPaAYXbhIUcxIPdQsPEnAXbhIUcBMPdQsPEnAXGBgUAGkPAwBGQ19ZDxgDFxlrFAAYQkVGWlkUAWsPA3QPGHdTR1BfHF5FFABsHkdxS38AdQ8Zd0ZLTRQBbktfWUAZAwIHGAEXGBgUAGkPAwBDR1BVTw8DAA8ZcBcYGFlGXlpCFxlrFABsDwN0Q0dQVU9ZH0dEWUFeS1lZHElFXBcYbEFaRV5eHxsfAQcdHwADHRgJBRwHV1MbEwMBSR9SBxgSFAFsWxQBbhIBFxgcRhcZbgkCGg8DBEtfRV0PGXVURVhcU14PAwRMQ0UXGW5SQEVaFAAYDwNxDxgDVk9ZUhcYGBQBaw8DAA9uCBcSEhR2Eg9wBQ9uCBcSGBR2Ew8Jcw8YARduEhRwGQ91Cw8ScBduExQKHg91Cw8ScBduExQKGQ91Cw8SCRduExQKHA8DAg9uCRdrEhR2Ew8JBg9uCBcSEhR2Ew8JBA8YARduEhRwHQ91Cg9rCRduExQKaw91Cg9oCBduExQKaw8DAg9uCBcSEhR2Eg9wcw9uCRdoHxR2Ew8JBw9uCBcSaxR2Ew8JBw8YARduExQKHw91Cg9oABduExQKaw91Cg9rdRcYGhR2Ew8Jcw9uCRdoHBR2Ew8Jcw9uCBcSGxQAGg91Cg9rBBduEhRzbg91Cg9oAhduEhRzHQ91Cg9oAhduExQKaA91Cg9rBhcYGhR2Eg9wCg9uCRdrHRR2Ew8JBg9uCRdrHRR2Ew8JBw9uCRdraxR2Ew8JBg9uCRdrHRR2Eg9wAw8YARduExQKEg91Cw8ScBduExQKHw91Cw8SBxduEhRzbg8DAg9uCRdraxR2Eg9wcQ9uCRdoGxR2Eg9wCg9uCRdrExQAGg91Cg9rAhduExQKGQ91Cg9rcxduEhRwGw8DAg9uCRdraxR2Ew8JBA9uCBcSEhR2Eg9zCw9uCBcSaBR2Eg9wBQ8YARduExQKHw91Cg9oCBcYGhR2Eg9zAQ9uCBcSHRR2Ew8JCg9uCBcSHhR2Eg9wCw8YARduEhRzHQ91Cw8SBRduEhRzHQ91Cg9oAhduEhRzaw91Cg9rdBduEhRzbA91Cg9rBhduExQKHwQUABgPBnYPGHIXHWgUABhDVRcYGBQBaxsAFxhpFAAYRFBfTw8DAA8ZcBcYGBR2Ew8JCg9uCRdrHRR2Ew8JAA9uCBcSaxQAGg91Cg9oAhduExQKaw91Cw8SBRduExQKaw91Cw8SAhduExQKEg91Cw8SBxcYGhR2Ew8JAw9uCRdrHRR2Eg9wBA9uCBcSGBQAGg91Cg9rBhduExQKHg91Cg9rcxduEhRzEg91Cg9rBhduEhRzaw8DAA8YchcYGF1bREEUABgPAnMPGANaXl5BQQ8ZcBcYbBQAbEtcSEQERV0PGHcGXGlTQXxDFAFsXlBVDxl1U0RBWwEYGhwAGg8DAA8YchcYGFhfS01UFxgYFAFrDwMAQl5FQlkPAnMPGHcXGGxYX0tNVEEEX19BWkZQQUIEUl1HDwN0WkJeRkUHAAcSHgEDHRMAAx0cBx9OHgQDSBlVAk8SBQEPGXdDDxl1ChoPAwRdDwJ2EhoBFxgcUEdeRRQBbkxeQEdLRRcYHFdbXg8CdklYXkIPGAMXGGkUABhOVEFJDwMADxlwFxgYFHYTDwkKD24JF2sdFHYTDwkAD24IFxJrFAAaD3UKD2gCF24TFAprD3ULDxIFF24TFAprD3ULDxICF24TFAoSD3ULDxIHFxgaFHYTDwkHD24JF2gbFHYTDwkEDxgBF24TFAofD3UKD2gEF24TFAofD3ULDxIEFxgaFHYTDwkGD24JF2toFHYSD3AKD24JF2sdFHYSD3BzDxgBF24SFHMZD3ULDxIAF24SFHAcD3ULDxIFFxgaFHYSD3ABD24JF2toFHYTDwkED24JF2sdFHYSD3ADDxgBF24SFHMdD3ULDxIFF24SFHMdD3UKD2gCF24SFHNrD3UKD2t0F24SFHNsD3UKD2sGF24TFAofD3UKDxJyFxgaFHYTDwkAD24JF2sdFHYSD3AKD24IFxIeFAAaD3ULDxIFF24TFAoeD3UKD2hwF24SFHAZD3ULDxIFFxgaFHYTDwkKD24JF2sfFHYSD3MLD24JF2sdFHYSD3B0D24JF2sTFAAaD3UKD2sGF24TFAoeD3UKD2sGF24SFHAZD3UKD2twF24SFHNvD3UKD2t3F24SFHMdD3ULDxIEFxgaFHYTDwkKD24IFxIfFHYSD3BzD24IFxISFHYSD3AFD24IFxIbFHYTDwkADxgBF24TFAofD3UKD2gIFxgaFHYTDwkHD24JF2gTFHYSD3MKD24IFxIfFAAaD3UKD2sGF24TFAoeD3ULDxIEF24SFHAYD3ULDxIFF24TFAoYD3UKD2sGF24SFHNrDwMCD24JF2sdFHYTDwkGD24IFxIfFHYSD3AFD24JF2scFHYTDwlzD24JF2sTHxcYGBQFbg8DcQ8dcxcYGFhWDxgDFxlrAAAPGHIXGBhfU0dPFAAYDwJzDxgDF24TFAofD3UKD2gDF24TFAoeD3ULDxIDFxgaFHYTDwkHD24JF2sdFHYSD3AED24IFxJrFAAaD3UKD2gIF24SFHMdD3ULDxIFF24TFAprDwMCD24JF2sdFHYTDwkGD24JF2tpFHYTDwkKD24JF2tsFHYSD3ALDxgDFxhpFAAYRlhcQQ8DAA8ZcBcYGFlGXlpCFxlrFABsDwN0S0dLXAReXhcYbAVKfF16Yh0PAnReS1YXGW5QXEFAAgAaBwMCDxgDFxhpFAAYQ1xTTU8UABgPAnMPGANaXl5BQQ8ZcBcYbBQAbENcU01PQhxfREJCRktCWgRJXl8PGHdCQkVFXQcbBAIdHAcKGh0GAxgTHAccTwIAEh4DVElPUxcZbEAXGW4JAg8YB0UPGXUKGhoUABxLREZFDwJ2TEVDX0teFAAcTFhGDxl1UVhFQRcYGBQAaQ8DAE5PQlEPGAMXGWsUABgPdQsPEgQXbhIUcBgPdQsPEgUXbhMUChgPAwIPbggXEh8UdhIPcAUPbgkXaxwUdhMPCXMPGAEXbhIUcBMPdQoPawYXbhMUCh4PdQsPEnAXGBoUdhIPcAUPbggXEh4UdhIPcHEPbggXEhIUdhIPcHQPbgkXaxMUABoPdQsPEnAXbhIUcBkPdQoPawYXbhIUcBMPdQoPa3cXGBoUdhIPcwsPbggXEh4UdhMPCQsPGAEXbhIUc2sPdQsPEgMXbhMUCh4PdQsPEnAXbhMUCh4PAwIPbgkXax0UdhMPCQYPbgkXax0UdhIPcHYPbgkXa2sUdhMPCQEPbgkXax0UdhMPCQEPGAEXbhMUChIPdQoPaAMXbhMUCmsPdQoPawYXbhIUc2wPdQoPawgXGBoUdhIPcAUPbggXEh4UdhIPcwMPbgkXax0UdhIPcHYPbgkXaxMUABoPdQoPawIXbhIUc2gPdQsPEgcXbhIUcx0PdQoPawAXGBoUdhIPcAUPbggXEh4UdhIPcAUPbgkXaBkUdhIPcHMPbgkXa28UdhIPcHQPbgkXax0UdhMPCQcPbgkXEmkUABoPdQoPawkXbhIUc2sPdQoPaAAXbhMUChkPdQsPEnAXbhIUcxIPdQoPawgXGBoUdhMPCQYPbgkXaB0UdhMPCXMPbggXEhsUdhIPcAsPGAEXbhMUChIPdQoPaAIXbhMUCh0PdQsPEgUXbhIUcxMPAwIPbgkXax0UdhMPCQYPbgkXa2sUdhMPCQQPbgkXaBIUdhMPCXMPbggXEhsUdhIPCXEPGAEXbhMUChIPdQsPEgQXbhIUc2sPdQsPEgkXbhIUcx0PdQsPEgAXbhMUChgPAwIPbggXEh8UdhIPcwsPGAEXbhMUCh8PdQoPaAgXbhIUcBIPdQsPEgQXGBoUdhMPCQcPbggXEhwUdhIPcHMPbgkXa2kUdhIPcAUPbgkXa2sUABoPdQoPawYXbhMUCh4PdQoPaAIXbhMUCmsPdQsPEgUXbhMUCmsPdQsPEgIXbhMUChIPdQsPEgcXGBoUdhMPCQoPbgkXax0UdhMPCQYPbggXEhIUdhIPcAUPbggXEhgUdhMPCXMPbgkXax0UdhIPcHMEDwMADx11FxhpFAVoDwMAQ04UABgPAnMbGRQAaQ8DAERLXFcPGAMXGWsUABgPdQsPEgQXbhIUcBgPdQsPEgUXbhMUChgPAwIPbggXEh8UdhIPcAUPbgkXaxwUdhMPCXMPGAEXbhMUChsPdQoPawYXbhIUcxwPdQsPEgMXGBoUdhIPcAUPbggXEh4UdhIPcAUPbggXEhwUdhIPcwEPbggXEmsUdhIPcAUPbgkXaxIUdhMPCXMPbgkXaxMUABgPA3EPGANeQ0RaFxgYFAFrDwMAQl5FQlkPAnMPGHcXGGxQX1BEH0ZFDwN0GXt0cWFPQRcZbEVTTQ8CdktEWlgZGAEfGBoUABgPA3EPGANbR0tWVw8YAxcZaxQAGEJFRlpZFAFrDwN0Dxh3W0dLVldZBERcWVpdU1lCH1FFRxQAbFpZXV5FHAMfHQgEEh4CCh8bAwUHG1RUGx9VBxoSAAMSDwJ0Ww8CdhIaFAAcXRQBbhIBAg8YB1NfXl4XGW5XXVhHUEYPGAdUQ14UAW5JQ11aDwMADxhyFxgYVVdZSRQAGA8Ccw8YAxduExQKHw91Cg9oAxduExQKHg91Cw8SAxcYGhR2Ew8JBw9uCRdrHRR2Eg9wBA9uCBcSaxQAGg91Cg9rCRduEhRzaw91Cg9oABduExQKGQ91Cw8ScBduEhRzEg91Cg9rCBcYGhR2Eg9wBQ9uCBcSHBR2Eg9zAQ9uCBcSaxR2Eg9wBQ9uCRdrEhR2Ew8Jcw9uCRdrExQAGg91Cw8ScBduExQKHw91Cw8SBxduEhRzbg8DAg9uCRdraxR2Eg9zAw9uCRdoHRR2Ew8Jcw9uCRdrEhR2Ew8JcA9uCRdrHRQAGg91Cw8ScBduEhRzbA91Cw8SCRduExQKHw8DAg9uCBcSHhR2Ew8JAw9uCRdraxR2Eg9zAw9uCRdrExQAGg91Cw8SBBduExQKHA91Cg9rBhduEhRwGQ91Cg9rCRduEhRzEw91Cg8SchcYGhR2Ew8JCg9uCBcSaxR2Eg9zAQ9uCRdrHRR2Eg9zCw9uCRdrbBQAGg91Cg9oCBduExQKHg91Cw8SCBcYGhR2Eg9wcw9uCRdraRR2Eg9zAw9uCRdrEhR2Eg9wCw8YARduEhRzGQ91Cw8SAhduEhRzaA91Cg9oABcYGhR2Eg9zAw9uCRdrHRR2Eg9wdg9uCRdrExQAGg91Cw8SCRduEhRwGQ91Cw8SBRduEhRzHQ91Cg9oAhduEhRzEw91Cg8SchcYGhR2Ew8JBw9uCRdoExQAGg91Cg9oAhduExQKHQ91Cw8SCRduExQKHg91Cg9rCBcYGhR2Eg9wBQ9uCBcSHhR2Eg9zcw9uCRdoGRR2Ew8JBg8YARduExQKEg91Cg9oCBduEhRzbA91Cw8SBBcYGhR2Eg9wcw9uCRdoGxR2Ew8JAQ8YARduEhRzGA91Cg9rcxduEhRzHQ91Cg9oABcYGhR2Ew8JBg9uCRdoGBR2Eg9wcQ9uCRdrEx8XGBgUBW4PBHY=";

const decryptProducts = (key: string) => {
    try {
        const text = atob(encryptedProducts);
        let result = '';
        for(let i=0; i<text.length; i++) {
            result += String.fromCharCode(text.charCodeAt(i) ^ key.charCodeAt(i % key.length));
        }
        return JSON.parse(decodeURIComponent(result));
    } catch (e) {
        return [];
    }
};

const elderlyProducts = [
  { id: 101, name: "حاجز سرير لمساعدة كبار السن", link: "https://amzn.to/4uOVGoK?tag=ankj320-20", image: "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=800&q=80", desc: "حاجز متين وقابل للتعديل يمنح كبار السن الدعم اللازم للنهوض من السرير بأمان، مزود بجيوب للتخزين وسهل التركيب بدون أدوات لضمان الراحة والاستقلالية.", features: ["سهل التركيب", "هيكل معدني قوي", "جيوب تخزين عملية"], reason: "يمنع السقوط من السرير ويوفر استقلالية تامة لكبار السن." },
  { id: 102, name: "عصا مشي قابلة للطي مع إضاءة", link: "https://amzn.to/4xHFOHk?tag=ankj320-20", image: "https://images.unsplash.com/photo-1599320875322-261ba05dbfb7?w=800&q=80", desc: "عصا مشي طبية مزودة بقاعدة رباعية مانعة للانزلاق وإضاءة LED مدمجة لتسهيل الحركة في الظلام. خفيفة الوزن وقابلة للطي لسهولة التخزين والحمل.", features: ["إضاءة مدمجة", "قاعدة رباعية ثابتة", "قابلة للطي"], reason: "توفر الثبات والأمان أثناء المشي في جميع الظروف." },
  { id: 103, name: "جهاز تدليك القدمين الحراري", link: "https://amzn.to/4gynvy2?tag=ankj320-20", image: "https://images.unsplash.com/photo-1631549916768-4119b2e5f926?w=800&q=80", desc: "جهاز تدليك احترافي يعمل على تحسين الدورة الدموية في القدمين وتخفيف التورم والشعور بالثقل، مع تقنيات الاهتزاز والحرارة لتجربة استرخاء لا مثيل لها.", features: ["تدليك حراري", "يخفف آلام القدمين", "تصميم مريح"], reason: "يخفف آلام القدمين المزمنة ويساعد على الاسترخاء العميق." },
  { id: 104, name: "جهاز تدليك الظهر والرقبة", link: "https://amzn.to/4afSTxv?tag=ankj320-20", image: "https://images.unsplash.com/photo-1631679706909-1844bbd07221?w=800&q=80", desc: "وسادة تدليك شياتسو فعالة للظهر والرقبة والأكتاف مع خاصية التدفئة، تساعد على إرخاء العضلات المتشنجة وتخفيف التوتر بعد يوم طويل.", features: ["تدليك شياتسو عميق", "خاصية التدفئة المريحة", "تخفيف التوتر العضلي"], reason: "يريح العضلات المتصلبة ويمنح شعوراً بالراحة الفورية." },
  { id: 105, name: "بساط تدليك لكامل الجسم", link: "https://amzn.to/4a8vv52?tag=ankj320-20", image: "https://images.unsplash.com/photo-1628144613271-e945c1103c81?w=800&q=80", desc: "بساط تدليك متكامل يهتز بلطف لتدليك الرقبة والظهر والخصر والساقين، مزود بوظيفة الحرارة ووسادة رقبة قابلة للفصل لتجربة تدليك شاملة.", features: ["تدليك لكامل الجسم", "حرارة مهدئة", "وسادة قابلة للفصل"], reason: "يوفر تجربة تدليك متكاملة تريح الجسم بالكامل." },
  { id: 106, name: "لفافة تدليك الكاحل والقدمين", link: "https://amzn.to/3QCW7V9?tag=ankj320-20", image: "https://images.unsplash.com/photo-1584622650111-993a426fbf0a?w=800&q=80", desc: "لفافة تدليك قابلة للارتداء توفر حرارة واهتزازات قابلة للتعديل لدعم الكاحل والقدمين، تساعد في تخفيف الألم وتسريع التعافي بشكل آمن.", features: ["مستويات حرارة متعددة", "محمولة وقابلة للارتداء", "تخفيف مركز للألم"], reason: "حل عملي ومريح لآلام المفاصل والكاحل." },
  { id: 107, name: "جهاز تدليك الركبة اللاسلكي", link: "https://amzn.to/4uQgrQT?tag=ankj320-20", image: "https://images.unsplash.com/photo-1516962215378-7fa2e137ae93?w=800&q=80", desc: "دعامة ركبة كهربائية مزودة بتقنية التدليك والحرارة لتخفيف آلام الركبة المزمنة. تصميم لاسلكي يتيح حرية الحركة أثناء الاستخدام، مثالي لكبار السن.", features: ["تدليك اهتزازي", "حرارة قابلة للتعديل", "تصميم لاسلكي مريح"], reason: "يساعد بشكل فعال في التخلص من تيبس وآلام الركبة." },
  { id: 108, name: "كرسي رفع كهربائي داعم للوقوف", link: "https://amzn.to/4w3GdCd?tag=ankj320-20", image: "https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?w=800&q=80", desc: "أداة رفع متطورة تساعد كبار السن على الوقوف والجلوس بسهولة واستقلالية، سواء في غرفة المعيشة أو أثناء الاستحمام، ويتحمل أوزاناً تصل إلى 135 كجم.", features: ["آلية رفع قوية", "يساعد على الاستقلالية", "متعدد الاستخدامات"], reason: "يحمي من السقوط ويسهل الحركة والقيام بشكل آمن." },
  { id: 109, name: "حذاء طبي رجالي مقاوم للانزلاق", link: "https://amzn.to/3Smhnz1?tag=ankj320-20", image: "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=800&q=80", desc: "حذاء صُمم بعناية لتوفير الأمان والراحة للقدمين، مع نعل خارجي مقاوم للانزلاق والماء، مثالي للمشي براحة وثبات عالي لكبار السن.", features: ["نعل مقاوم للانزلاق", "مريح وخفيف الوزن", "سهل الارتداء والخلع"], reason: "يحمي من الانزلاق ويوفر راحة تامة طوال اليوم." },
  { id: 110, name: "حذاء منزلي مريح للنساء", link: "https://amzn.to/4uNyxCW?tag=ankj320-20", image: "https://images.unsplash.com/photo-1538329972958-465d6d2144ed?w=800&q=80", desc: "حذاء منزلي طبي مزود برغوة الذاكرة (Memory Foam) وحزام قابل للتعديل لتوفير أقصى درجات الراحة والدعم للقدمين الحساستين.", features: ["بطانة رغوة الذاكرة", "قابل للتعديل", "نعل داعم للقدم"], reason: "يوفر دفئاً وراحة استثنائية للاستخدام اليومي داخل المنزل." },
  { id: 111, name: "جهاز قياس نسبة الأكسجين في الدم", link: "https://amzn.to/3QXgdcK?tag=ankj320-20", image: "https://images.unsplash.com/photo-1518614900918-6395b0bd822b?w=800&q=80", desc: "جهاز طبي احترافي وموثوق لمراقبة مستويات الأكسجين ومعدل ضربات القلب بدقة عالية، مزود بشاشة واضحة وإنذارات للتنبيه عند الحاجة.", features: ["قياس دقيق وسريع", "شاشة واضحة القراءة", "تنبيهات مدمجة"], reason: "أداة ضرورية لمراقبة الحالة الصحية بشكل يومي." },
  { id: 112, name: "جهاز تقوية السمع بالتوصيل العظمي", link: "https://www.amazon.com/dp/B0H1CR8V47?tag=ankj320-20", image: "https://images.unsplash.com/photo-1576091160550-2173ff9e5ee5?w=800&q=80", desc: "سماعة مبتكرة لتقوية السمع تستخدم تقنية التوصيل العظمي وتترك الأذن مفتوحة. خفيفة جداً ومقاومة للماء، مصممة خصيصاً لراحة كبار السن.", features: ["تقنية التوصيل العظمي", "تصميم مريح للأذن المفتوحة", "بطارية تدوم طويلاً"], reason: "حل متطور ومريح لتحسين جودة السمع دون إزعاج." },
  { id: 114, name: "ماكينة حلاقة كهربائية فيليبس نوريلكو", link: "https://www.amazon.com/dp/B0DKTTWYJJ?th=1&language=ar_AE&tag=ankj320-20", image: "https://images.unsplash.com/photo-1516574187841-cb9cc2ca948b?w=800&q=80", desc: "ماكينة حلاقة متطورة للوجه والجسم بتقنية 360 درجة لتشذيب دقيق وسلس. تأتي مع ملحقات متعددة وسهلة الاستخدام لكبار السن.", features: ["تشذيب دقيق وسريع", "آمنة على البشرة", "متعددة الاستخدامات"], reason: "تضمن عناية شخصية سهلة ومريحة بدون أي مجهود." },
  { id: 115, name: "سماعات طبية صغيرة لتقوية السمع", link: "https://www.amazon.com/dp/B0GV3NR8GX?language=ar_AE&tag=ankj320-20", image: "https://images.unsplash.com/photo-1584308666744-24d5e478eb04?w=800&q=80", desc: "سماعات أذن متطورة قابلة لإعادة الشحن، مزودة بتقنية تقليل الضوضاء الذكية وشاشة لعرض نسبة الشحن، سهلة التشغيل ومخفية داخل الأذن.", features: ["تقليل الضوضاء بفعالية", "تصميم صغير غير مرئي", "سهولة الشحن والتشغيل"], reason: "تعيد الثقة لكبار السن وتسهل تواصلهم مع من حولهم." },
  { id: 116, name: "سماعة طبية لتقوية السمع حول الرقبة", link: "https://www.amazon.com/dp/B0FVRF5JMJ?language=ar_AE&tag=ankj320-20", image: "https://images.unsplash.com/photo-1631549916768-4119b2e5f926?w=800&q=80", desc: "سماعة بتصميم عملي حول الرقبة لتقوية السمع ودعم اتصال البلوتوث، مما يتيح لكبار السن الاستماع بوضوح والرد على المكالمات براحة تامة.", features: ["تصميم عملي حول الرقبة", "دعم البلوتوث للمكالمات", "سهلة التحكم بمستوى الصوت"], reason: "تصميم يحمي من الضياع ويوفر تجربة سمعية ممتازة." }
];

const carProducts = [
  { id: 201, name: "ضوء حماية السيارة بالطاقة الشمسية", link: "https://amzn.to/43PeM2X?tag=ankj320-20", image: "https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?w=800&q=80", desc: "وفر حماية إضافية لسيارتك من اللصوص مع ضوء إنذار يعمل بالطاقة الشمسية. يومض تلقائياً أثناء الليل ليعطي انطباعاً بوجود نظام إنذار حقيقي دون الحاجة إلى بطاريات أو توصيلات كهربائية.", features: ["مبتكر", "آمن", "سلس الاستخدام"], reason: "يعتبر من أفضل الخيارات في فئته." },
  { id: 202, name: "مكنسة سيارة لاسلكية قوية", link: "https://amzn.to/4gy1Rdg?tag=ankj320-20", image: "https://images.unsplash.com/photo-1489824904114-8b156312ea08?w=800&q=80", desc: "حافظ على نظافة سيارتك بسهولة مع مكنسة لاسلكية بقوة شفط عالية تصل إلى 9500PA. تصميم خفيف ومحمول مع فوهات متعددة للوصول إلى أصعب الزوايا داخل السيارة أو المنزل أو المكتب.", features: ["قيمة ممتازة", "عمر طويل", "متعدد الاستخدامات"], reason: "يضيف طابعاً شخصياً وعملياً للسيارة." },
  { id: 203, name: "منفاخ هواء لاسلكي للإطارات", link: "https://amzn.to/43OaARa?tag=ankj320-20", image: "https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?w=800&q=80", desc: "منفاخ هواء محمول وقوي للإطارات بشاشة رقمية وإضاءة LED. مثالي لنفخ إطارات السيارات والدراجات النارية والكرات بسرعة وسهولة وبدون عناء.", features: ["تصميم مدمج", "فعال", "مواد متينة"], reason: "يوفر حلاً ذكياً لمشاكل يومية." },
  { id: 204, name: "علبة فيوزات 6 دوائر", link: "https://amzn.to/3Sm6ahU?tag=ankj320-20", image: "https://images.unsplash.com/photo-1511919884226-fd3cad34687c?w=800&q=80", desc: "نظم التوصيلات الكهربائية في سيارتك بشكل آمن مع علبة فيوزات 6 دوائر، مزودة بغطاء مقاوم للماء وملصقات لتحديد كل دائرة بسهولة وحماية الأجهزة.", features: ["مظهر جذاب", "وظائف متعددة", "تركيب سريع"], reason: "يضيف لمسة جمالية ووظيفية ممتازة." },
  { id: 205, name: "علبة الفيوزات الإضافية 12 دائرة", link: "https://amzn.to/4b0Yp7g?tag=ankj320-20", image: "https://images.unsplash.com/photo-1503376712614-75ebcebd7055?w=800&q=80", desc: "نظم جميع إضافات سيارتك بطريقة احترافية وآمنة مع علبة الفيوزات الإضافية 12 دائرة. توفر حماية مستقلة لكل جهاز، وتمنع الفوضى الكهربائية، مما يجعل تركيب الإضاءات والكاميرات والشواحن وغيرها أكثر أماناً وسهولة.", features: ["سهل الاستخدام", "متين", "مناسب للرحلات"], reason: "يعتبر إضافة ضرورية لسيارتك." },
  { id: 206, name: "شاشة عرض المعلومات HUD", link: "https://amzn.to/4wmU7Qf?tag=ankj320-20", image: "https://images.unsplash.com/photo-1552519507-da3b142c6e3d?w=800&q=80", desc: "استمتع بقيادة أكثر أماناً مع شاشة HUD التي تعرض سرعة السيارة والمعلومات الأساسية مباشرة أمامك على الزجاج الأمامي، مما يساعدك على التركيز على الطريق دون الحاجة للنظر إلى لوحة العدادات.", features: ["كفاءة عالية", "مجرب وموثوق", "تصميم عملي"], reason: "يلبي احتياجاتك بفعالية كبيرة." },
  { id: 207, name: "عدة إصلاح ثقوب الإطارات 45 قطعة", link: "https://amzn.to/4oCH6PC?tag=ankj320-20", image: "https://images.unsplash.com/photo-1549060279-7e168fcee0c2?w=800&q=80", desc: "لا تدع ثقباً صغيراً يعطل رحلتك. تحتوي هذه العدة المتكاملة على جميع الأدوات اللازمة لإصلاح ثقوب الإطارات بسرعة خلال دقائق، لتعود للطريق بأمان دون انتظار المساعدة أو سحب السيارة.", features: ["أداء عالي", "موثوقية", "سهل التركيب"], reason: "يزيد من أمان وراحة الركاب." },
  { id: 208, name: "شاشة HUD الذكية للزجاج الأمامي", link: "https://amzn.to/4vrNxYu?tag=ankj320-20", image: "https://images.unsplash.com/photo-1501066927591-314112b5eaed?w=800&q=80", desc: "تقنية حديثة تعرض بيانات القيادة مثل السرعة وعدد دورات المحرك والجهد والبوصلة بشكل واضح أمام السائق. سهلة التركيب ومتوافقة مع معظم السيارات لتجربة قيادة أكثر راحة وأماناً.", features: ["أداء استثنائي", "ضمان جودة", "مريح"], reason: "يحافظ على راحة الركاب وسائق السيارة." },
  { id: 209, name: "جهاز فحص السيارات الاحترافي OBD2", link: "https://amzn.to/4vGTpgN?tag=ankj320-20", image: "https://images.unsplash.com/photo-1600705662369-026857f1edac?w=800&q=80", desc: "اكتشف أعطال سيارتك خلال دقائق دون الحاجة للذهاب مباشرة إلى الورشة. يقوم جهاز فحص السيارات OBD2 بقراءة أكواد الأعطال، ومسح لمبة المكينة، وعرض معلومات دقيقة عن حالة السيارة، مما يساعدك على اتخاذ القرار الصحيح وتوفير تكاليف الصيانة.", features: ["جودة ممتازة", "عملي جداً", "تصميم عصري"], reason: "يحسن من تجربة القيادة بشكل ملحوظ." },
  { id: 210, name: "ضوء عيون الشيطان الذكي للسيارة", link: "https://amzn.to/4uQW9a1?tag=ankj320-20", image: "https://images.unsplash.com/photo-1494976388531-d1058494cdd8?w=800&q=80", desc: "أضف مظهراً رياضياً وفريداً لسيارتك مع ضوء عيون الشيطان الذكي. يعمل بالطاقة الشمسية ويضيء تلقائياً ليلاً مع مستشعر اهتزاز ليمنح سيارتك شكلاً مميزاً يجذب الأنظار.", features: ["أنيق", "تقنية حديثة", "سهل التنظيف"], reason: "يرفع من مستوى التجهيزات في سيارتك." }
];

const chunkArray = (arr: any[], size: number) => {
  const chunked = [];
  for (let i = 0; i < arr.length; i += size) {
    chunked.push(arr.slice(i, i + size));
  }
  return chunked;
};

const compressImage = (file: File, maxWidth = 800, maxHeight = 800, quality = 0.7): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = (event) => {
      const img = new Image();
      img.src = event.target?.result as string;
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;

        if (width > maxWidth) {
          height = Math.round((height * maxWidth) / width);
          width = maxWidth;
        }
        if (height > maxHeight) {
          width = Math.round((width * maxHeight) / height);
          height = maxHeight;
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL('image/jpeg', quality));
      };
      img.onerror = (e) => reject(e);
    };
    reader.onerror = (e) => reject(e);
  });
};

export default function App() {
  const [products, setProducts] = React.useState<any[]>([]);
  const [selectedProduct, setSelectedProduct] = React.useState<any | null>(null);
  const [productImages, setProductImages] = React.useState<Record<number, string>>(() => {
    try {
      const saved = localStorage.getItem('productImages');
      return saved ? JSON.parse(saved) : {};
    } catch (e) {
      return {};
    }
  });

  const [coverImage, setCoverImage] = React.useState<string>(() => {
    return localStorage.getItem('magazineCover') || "";
  });

  React.useEffect(() => {
    const migrateAndLoad = async () => {
      try {
        const idbImages = await get('productImages');
        if (idbImages) {
          setProductImages(prev => ({ ...prev, ...idbImages }));
        } else {
          const local = localStorage.getItem('productImages');
          if (local) await set('productImages', JSON.parse(local));
        }

        const idbCover = await get('magazineCover');
        if (idbCover) {
          setCoverImage(idbCover);
        } else {
          const local = localStorage.getItem('magazineCover');
          if (local) await set('magazineCover', local);
        }
      } catch (e) {
        console.error("Migration failed", e);
      }
    };
    migrateAndLoad();
  }, []);

  const handleCoverUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      try {
        const compressedBase64 = await compressImage(file, 1600, 1600, 0.8);
        setCoverImage(compressedBase64);
        try {
          await set('magazineCover', compressedBase64);
        } catch (idbError) {
          localStorage.setItem('magazineCover', compressedBase64);
        }
      } catch (e) {
        console.error("Storage error", e);
        alert("حدث خطأ أثناء معالجة أو حفظ الصورة.");
      }
    }
  };

  const handleImageUpload = async (productId: number, event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      try {
        const compressedBase64 = await compressImage(file, 800, 800, 0.8);
        setProductImages(prev => {
          const newState = { ...prev, [productId]: compressedBase64 };
          set('productImages', newState).catch(() => {
            try {
              localStorage.setItem('productImages', JSON.stringify(newState));
            } catch (storageError) {
              console.error("Storage quota exceeded", storageError);
              alert("مساحة التخزين ممتلئة، سيتم عرض الصورة مؤقتاً فقط.");
            }
          });
          return newState;
        });
      } catch (e) {
        console.error("Compression error", e);
        alert("حدث خطأ أثناء معالجة الصورة.");
      }
    }
  };

  const renderMagazinePages = (items: any[], type: 'health' | 'elderly' | 'cars') => {
    const pages = chunkArray(items, 4);
    return pages.map((pageProducts, pageIndex) => {
      return (
        <section key={pageIndex} className="py-12 px-6 bg-[#FFFFF0] force-page-break border-b border-slate-200 flex flex-col justify-center" style={{ minHeight: '29.7cm' }}>
          <div className="max-w-[1000px] w-full mx-auto flex flex-col h-full">
            {pageIndex === 0 && (
              <div className="mb-10 avoid-page-break">
                <div className="text-center mb-8">
                  <h2 className="text-3xl md:text-4xl font-black text-[#0A192F] mb-4 tracking-wide uppercase" style={{fontFamily: 'serif'}}>
                    {type === 'health' ? 'المنتجات المختارة' : type === 'elderly' ? 'منتجات بر الوالدين' : 'قسم سيارات مهمة'}
                  </h2>
                  <div className="h-px bg-[#D4AF37] w-24 mx-auto mb-4"></div>
                </div>
                {type === 'health' && (
                  <div className="bg-white border-2 border-rose-100 rounded-2xl p-6 shadow-sm mb-8 text-right text-[#0A192F]">
                    <h3 className="text-xl font-bold mb-4 text-rose-700 flex items-center gap-2">
                      <span>📌</span> تنبيهات وملاحظات هامة قبل الطلب
                    </h3>
                    <p className="mb-4 text-slate-600 font-medium">عزيزنا العميل، يرجى مراجعة النقاط التالية بعناية لضمان تجربة تسوق وشحن سلسة وناجحة:</p>
                    <ul className="space-y-4 text-slate-700">
                      <li className="flex gap-3">
                        <span className="text-xl">📦</span>
                        <div>
                          <strong className="block text-rose-800 mb-1">خيار التغليف والشحن:</strong>
                          لضمان وصول الشحنة بنجاح وبدون معوقات إلى بعض الدول، قد يلزمك تفعيل خيار (تغليف كهدية) عند إتمام الطلب، بتكلفة إضافية قدرها 3.99 دولار.
                        </div>
                      </li>
                      <li className="flex gap-3">
                        <span className="text-xl">⚖️</span>
                        <div>
                          <strong className="block text-rose-800 mb-1">الأنظمة والقوانين المحلية:</strong>
                          يرجى التأكد من أن المنتج مسموح باستيراده واستخدامه بالكامل وفقاً للأنظمة والقوانين السارية في دولتك قبل الشراء.
                        </div>
                      </li>
                      <li className="flex gap-3">
                        <span className="text-xl">💡</span>
                        <div>
                          <strong className="block text-rose-800 mb-1">نصيحة للاستخدام الأمثل:</strong>
                          لضمان أعلى درجات الراحة والحفاظ على جودة مادة السيليكون، يُنصح بشدة باستخدام مزلق مائي متوافق معها تماماً أثناء الاستخدام.
                        </div>
                      </li>
                    </ul>
                  </div>
                )}
              </div>
            )}
            
            <div className="flex-1 flex flex-col justify-center">
              <div className={`grid grid-cols-1 ${pageProducts.length === 3 ? 'md:grid-cols-3' : 'md:grid-cols-2'} gap-8 avoid-page-break`}>
                {pageProducts.map(product => (
                  <div key={product.id} className="group flex flex-col bg-white rounded-3xl p-6 shadow-sm border border-slate-100 relative hover:shadow-xl transition-all duration-300">
                    <div className="absolute top-8 right-8 z-20 print:hidden opacity-0 group-hover:opacity-100 transition-opacity">
                      <label className="cursor-pointer bg-white/90 p-2.5 rounded-full shadow-md hover:bg-[#F3F4F6] transition-colors border border-slate-200 flex items-center justify-center">
                        <input type="file" className="hidden" accept="image/*" onChange={(e) => handleImageUpload(product.id, e)} />
                        <Upload className="w-4 h-4 text-[#0A192F]" />
                      </label>
                    </div>
                    <div className="w-full aspect-[4/3] overflow-hidden bg-[#F3F4F6] rounded-2xl relative mb-6">
                      <img src={productImages[product.id] || product.image} alt={product.name} className="absolute inset-0 w-full h-full object-cover mix-blend-multiply transition-transform duration-700 group-hover:scale-105" />
                      <button className="absolute top-4 left-4 p-2.5 bg-white/80 backdrop-blur rounded-full text-slate-400 hover:text-rose-500 transition-colors shadow-sm">
                        <Heart className="w-5 h-5" />
                      </button>
                    </div>
                    <div className="px-2 pb-2 text-right flex flex-col flex-1">
                      <h3 className="text-xl font-bold text-[#0A192F] mb-3 line-clamp-2 leading-snug" style={{fontFamily: 'serif'}}>{product.name}</h3>
                      <p className="text-sm text-slate-500 line-clamp-2 mb-6 leading-relaxed flex-1">{product.desc}</p>
                      
                      <div className="flex flex-col gap-4 mt-auto pt-4 border-t border-slate-50">
                        <div className="flex items-center justify-between flex-row-reverse">
                          <div className="flex items-center gap-1.5 bg-slate-50 px-3 py-1.5 rounded-full">
                            <span className="text-sm font-bold text-slate-700">4.8</span>
                            <Star className="w-4 h-4 text-[#D4AF37] fill-current" />
                          </div>
                          <button onClick={() => setSelectedProduct(product)} className="px-5 py-2 bg-slate-50 hover:bg-slate-200 text-[#0A192F] rounded-full text-sm font-bold transition-colors uppercase tracking-wider">
                            التفاصيل
                          </button>
                        </div>
                        <a href={product.link} target="_blank" rel="noopener noreferrer" className="w-full py-3 bg-[#0A192F] text-white hover:bg-[#D4AF37] rounded-xl font-bold flex items-center justify-center gap-2 transition-colors print:hidden shadow-md hover:shadow-lg">
                          <span>شراء المنتج</span>
                          <ShoppingCart className="w-5 h-5" />
                        </a>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>
      );
    });
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'مجلة الصحة والتوافق الزوجي',
          text: 'دليلك لاختيارات آمنة، مبتكرة، ومثبتة الفعالية',
          url: window.location.href,
        });
      } catch (error: any) {
        if (error.name !== 'AbortError') {
          console.error('Error sharing:', error);
        }
      }
    } else {
      alert('عذراً، متصفحك لا يدعم خاصية المشاركة المباشرة.');
    }
  };

  const handleExportPDF = () => {
    setIsExporting(true);
    window.scrollTo(0, 0);
    setTimeout(() => {
      const element = document.getElementById("main-content");
      if (!element) {
          window.print();
          setIsExporting(false);
          return;
      }
      const opt = {
        margin:       0,
        filename:     "ch-filter-magazine.pdf",
        image:        { type: "jpeg", quality: 0.98 },
        html2canvas:  { scale: 2, useCORS: true, scrollY: 0, logging: false },
        jsPDF:        { unit: "mm", format: "a4", orientation: "portrait" },
        pagebreak:    { mode: ["css", "legacy"] }
      };
      html2pdf().set(opt).from(element).save().then(() => {
        setIsExporting(false);
      });
    }, 1500);
  };

  const handleExportHTML = async () => {
    try {
      const response = await fetch("/standalone.html");
      if (!response.ok) throw new Error("Network error");
      let htmlContent = await response.text();

      // Get styles
      const styleSheets = document.querySelectorAll('style');
      let styles = '';
      styleSheets.forEach(s => styles += s.innerHTML);

      // Inject data
      htmlContent = htmlContent.replace('${styles}', styles);
      htmlContent = htmlContent.replace('${JSON.stringify(elderlyProducts)}', JSON.stringify(elderlyProducts));
      htmlContent = htmlContent.replace('${JSON.stringify(carProducts)}', JSON.stringify(carProducts));
      htmlContent = htmlContent.replace('${JSON.stringify(productImages)}', JSON.stringify(productImages));
      htmlContent = htmlContent.replace('${encryptedProducts}', encryptedProducts);
      htmlContent = htmlContent.replace('${coverImage}', coverImage || "");

      const blob = new Blob([htmlContent], { type: "text/html;charset=utf-8" });
      const link = document.createElement("a");
      link.href = URL.createObjectURL(blob);
      link.download = "index.html"; // Renamed to index.html for easier Netlify upload
      link.click();
    } catch (e) {
      alert("تعذر تنزيل الملف، حاول مرة أخرى.");
    }
  };





  const [activeTab, setActiveTab] = React.useState<'home' | 'health' | 'elderly' | 'cars'>('home');
  const [isExporting, setIsExporting] = React.useState(false);
  const [showPasswordModal, setShowPasswordModal] = React.useState(false);
  const [passwordInput, setPasswordInput] = React.useState('');
  const [passwordError, setPasswordError] = React.useState(false);

  const handleHealthClick = () => {
    if (activeTab === 'health') return;
    setShowPasswordModal(true);
  };

  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (passwordInput === '*12*') {
      const decrypted = decryptProducts(passwordInput);
      setProducts(decrypted);
      setActiveTab('health');
      setShowPasswordModal(false);
      setPasswordInput('');
      setPasswordError(false);
    } else {
      setPasswordError(true);
    }
  };

  return (
    <>
      <div id="main-content" className={`min-h-screen relative selection:bg-[#D4AF37] selection:text-[#0A192F] bg-[#FFFFF0] pt-24 print:pt-0 ${isExporting ? 'exporting-mode' : ''}`}>
        
        {/* Premium Navigation Menu */}
        <nav className={`fixed top-0 left-0 right-0 z-[60] bg-white/80 backdrop-blur-md border-b border-slate-200 print:hidden ${isExporting ? "hidden" : ""}`} dir="rtl">
          <div className="max-w-[1200px] mx-auto px-6 py-4 flex items-center justify-between">
            <div className="font-serif font-black text-2xl text-[#0A192F] tracking-widest" dir="ltr">
              CH-FILTER
            </div>
            <div className="flex-1 flex items-center gap-2 overflow-x-auto no-scrollbar py-2 px-2" style={{ WebkitOverflowScrolling: 'touch' }}>
              <button 
                onClick={() => setActiveTab('home')}
                className={`flex-shrink-0 flex items-center gap-2 px-3 py-1.5 rounded-full font-bold transition-all whitespace-nowrap text-xs md:text-sm ${activeTab === 'home' ? 'bg-[#0A192F] text-white shadow-lg' : 'text-slate-700 bg-white hover:bg-slate-50 border border-slate-200'}`}
              >
                <Home className="w-4 h-4 md:w-5 md:h-5" />
                <span>الرئيسية</span>
              </button>
              <button 
                onClick={handleHealthClick}
                className={`flex-shrink-0 flex items-center gap-2 px-3 py-1.5 rounded-full font-bold transition-all border-2 whitespace-nowrap text-xs md:text-sm ${activeTab === 'health' ? 'bg-rose-500 text-white border-rose-500 shadow-rose-200 shadow-lg' : 'bg-rose-50 text-rose-700 border-rose-200 hover:bg-rose-100'}`}
              >
                <Heart className={`w-4 h-4 md:w-5 md:h-5 ${activeTab === 'health' ? 'text-white' : 'text-rose-500'}`} />
                <span>الصحة والتوافق</span>
              </button>
              <button 
                onClick={() => setActiveTab('elderly')}
                className={`flex-shrink-0 flex items-center gap-2 px-3 py-1.5 rounded-full font-bold transition-all border-2 whitespace-nowrap text-xs md:text-sm ${activeTab === 'elderly' ? 'bg-emerald-600 text-white border-emerald-600 shadow-emerald-200 shadow-lg' : 'bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100'}`}
              >
                <ShieldCheck className={`w-4 h-4 md:w-5 md:h-5 ${activeTab === 'elderly' ? 'text-white' : 'text-emerald-600'}`} />
                <span>بر الوالدين</span>
              </button>
              <button 
                onClick={() => setActiveTab('cars')}
                className={`flex-shrink-0 flex items-center gap-2 px-3 py-1.5 rounded-full font-bold transition-all border-2 whitespace-nowrap text-xs md:text-sm ${activeTab === 'cars' ? 'bg-blue-600 text-white border-blue-600 shadow-blue-200 shadow-lg' : 'bg-blue-50 text-blue-800 border-blue-200 hover:bg-blue-100'}`}
              >
                <Car className={`w-4 h-4 md:w-5 md:h-5 ${activeTab === 'cars' ? 'text-white' : 'text-blue-600'}`} />
                <span>قسم سيارات</span>
              </button>
            </div>
          </div>
        </nav>
      
      {/* Password Modal */}
      {showPasswordModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6 bg-[#0A192F]/60 backdrop-blur-xl print:hidden" onClick={() => setShowPasswordModal(false)}>
          <div className="bg-white rounded-3xl w-full max-w-md p-8 shadow-2xl relative animate-in fade-in zoom-in duration-300 text-center" onClick={e => e.stopPropagation()} dir="rtl">
            <button onClick={() => setShowPasswordModal(false)} className="absolute top-4 left-4 p-2 rounded-full hover:bg-slate-100 transition-colors">
              <X className="w-5 h-5 text-slate-500" />
            </button>
            <div className="w-16 h-16 bg-[#F3F4F6] rounded-full flex items-center justify-center mx-auto mb-6">
              <Heart className="w-8 h-8 text-[#D4AF37]" />
            </div>
            <h3 className="font-bold text-2xl text-[#0A192F] mb-2" style={{fontFamily: 'serif'}}>قسم الصحة والتوافق الزوجي</h3>
            <p className="text-slate-500 mb-8">الرجاء إدخال الرقم السري للوصول إلى هذا القسم.</p>
            <form onSubmit={handlePasswordSubmit} className="flex flex-col gap-4">
              <div>
                <input 
                  type="password" 
                  value={passwordInput}
                  onChange={(e) => { setPasswordInput(e.target.value); setPasswordError(false); }}
                  placeholder="الرقم السري"
                  className={`w-full px-5 py-4 bg-[#F3F4F6] rounded-xl border ${passwordError ? 'border-rose-500 focus:border-rose-500 focus:ring-rose-200' : 'border-transparent focus:border-[#D4AF37] focus:ring-[#D4AF37]/20'} outline-none transition-all text-center text-xl tracking-widest`}
                  autoFocus
                />
                {passwordError && <p className="text-rose-500 text-sm mt-2 font-medium">الرقم السري غير صحيح</p>}
              </div>
              <button type="submit" className="w-full bg-[#0A192F] text-white py-4 rounded-xl font-bold hover:bg-[#1a2d52] transition-colors mt-2 text-lg">
                دخول
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Product Modal */}
      {selectedProduct && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6 bg-[#0A192F]/60 backdrop-blur-xl print:hidden" onClick={() => setSelectedProduct(null)}>
          <div className="bg-[#FFFFF0] rounded-[2rem] w-full max-w-5xl max-h-[90vh] overflow-hidden shadow-2xl relative flex flex-col md:flex-row animate-in fade-in zoom-in duration-300" onClick={e => e.stopPropagation()}>
            <button onClick={() => setSelectedProduct(null)} className="absolute top-6 right-6 z-10 bg-white/50 backdrop-blur p-3 rounded-full hover:bg-white transition-colors shadow-sm">
              <X className="w-6 h-6 text-[#0A192F]" />
            </button>
            
            {/* Modal Image */}
            <div className="w-full md:w-2/5 bg-[#F3F4F6] relative flex items-center justify-center p-8 border-b md:border-b-0 md:border-r border-slate-200">
              <img 
                src={productImages[selectedProduct.id] || selectedProduct.image} 
                alt={selectedProduct.name} 
                className="w-full h-full object-cover mix-blend-multiply rounded-2xl"
              />
            </div>
            
            {/* Modal Content */}
            <div className="w-full md:w-3/5 p-8 md:p-12 overflow-y-auto flex flex-col bg-white" dir="rtl">
              <div className="flex items-center gap-2 mb-4">
                <div className="flex items-center gap-0.5 text-[#D4AF37]">
                  <Star className="w-5 h-5 fill-current" /><Star className="w-5 h-5 fill-current" /><Star className="w-5 h-5 fill-current" /><Star className="w-5 h-5 fill-current" /><Star className="w-5 h-5 fill-current" />
                </div>
                <span className="text-slate-500 font-bold">4.8 (1,234 تقييم)</span>
              </div>
              
              <h3 className="font-bold text-3xl md:text-5xl mb-6 text-[#0A192F] leading-tight" style={{fontFamily: 'serif'}}>{selectedProduct.name}</h3>
              
              {/* Fake Tabs for Apple-like feel */}
              <div className="flex gap-6 border-b border-slate-200 mb-8 pb-4">
                <span className="font-bold text-[#0A192F] border-b-2 border-[#0A192F] pb-4 -mb-4">نظرة عامة</span>
                <span className="text-slate-400 font-bold pb-4">المواصفات</span>
                <span className="text-slate-400 font-bold pb-4 hidden sm:block">المميزات</span>
                <span className="text-slate-400 font-bold pb-4">التقييمات</span>
              </div>

              <p className="text-xl text-slate-600 mb-8 leading-relaxed">
                {selectedProduct.desc}
              </p>
              
              {selectedProduct.features && (
                <div className="mb-8">
                  <h4 className="font-bold text-xl text-[#0A192F] mb-4">أهم المميزات</h4>
                  <ul className="space-y-4">
                    {selectedProduct.features.map((feat: string, idx: number) => (
                      <li key={idx} className="flex items-start gap-3 text-lg text-slate-600">
                        <CircleCheck className="w-6 h-6 text-[#D4AF37] shrink-0 mt-0.5" />
                        <span>{feat}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {selectedProduct.reason && (
                <div className="bg-[#FFFFF0] border border-[#D4AF37]/30 rounded-2xl p-6 mb-10">
                  <h4 className="font-bold text-lg text-[#0A192F] mb-3 flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-[#D4AF37]" />
                    سبب الترشيح
                  </h4>
                  <p className="text-lg text-slate-600 leading-relaxed">
                    {selectedProduct.reason}
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Luxury Image Cover Page */}
      <div className={`section-magazine ${activeTab === 'home' || isExporting ? 'active' : ''}`}>
          <section className="relative w-full flex flex-col items-center justify-center avoid-page-break force-page-break overflow-hidden bg-white" style={{ minHeight: '29.7cm' }}>
            {coverImage ? (
              <img 
                src={coverImage}
                alt="CH-Filter Magazine Cover" 
                className="absolute inset-0 w-full h-full object-cover"
              />
            ) : (
              <div className="absolute inset-0 w-full h-full flex flex-col items-center justify-center bg-[#F3F4F6] p-12">
                 <div className="border border-[#D4AF37] p-16 flex flex-col items-center bg-white shadow-2xl rounded-3xl">
                   <h1 className="text-7xl font-serif font-black text-[#0A192F] mb-6">CH-FILTER</h1>
                   <p className="text-2xl text-slate-500 font-serif italic mb-8">Luxury Editorial Magazine</p>
                   <p className="text-lg text-slate-400">Please upload your cover image using the button below</p>
                 </div>
              </div>
            )}
            <label className={`absolute z-20 cursor-pointer bg-white/90 p-4 rounded-full shadow-2xl hover:bg-[#F3F4F6] transition-colors border border-slate-200 flex items-center gap-3 backdrop-blur-md group print:hidden ${isExporting ? "hidden" : ""}`}>
              <input 
                type="file" 
                className="hidden" 
                accept="image/*"
                onChange={handleCoverUpload}
              />
              <Upload className="w-6 h-6 text-[#0A192F] group-hover:scale-110 transition-transform" />
              <span className="font-bold text-[#0A192F]">Upload Cover Image</span>
            </label>
          </section>

          {/* Action Buttons - Hidden in Print */}
          <div className={`w-full bg-[#0A192F] px-6 py-6 flex flex-col sm:flex-row items-center justify-center gap-6 print:hidden ${isExporting ? "hidden" : ""}`}>
            <button 
              onClick={handleExportPDF}
              className="w-full sm:w-auto bg-[#D4AF37] text-white px-10 py-4 rounded-full shadow-lg hover:bg-amber-400 hover:scale-105 transition-all flex items-center justify-center gap-4 font-bold text-lg" 
              title="تصدير المجلة كملف PDF عالي الجودة"
            >
              <Download className="w-6 h-6" />
              <span>Export (PDF)</span>
            </button>
            <button 
              onClick={handleExportHTML}
              className="w-full sm:w-auto bg-emerald-600 text-white px-10 py-4 rounded-full shadow-lg hover:bg-emerald-500 hover:scale-105 transition-all flex items-center justify-center gap-4 font-bold text-lg" 
              title="تصدير المجلة كملف HTML كامل يعمل بدون إنترنت"
            >
              <Download className="w-6 h-6" />
              <span>Export (HTML)</span>
            </button>
            <button 
              onClick={handleShare}
              className="w-full sm:w-auto bg-white text-[#0A192F] px-10 py-4 rounded-full shadow-lg border border-slate-200 hover:bg-slate-50 hover:scale-105 transition-all flex items-center justify-center gap-4 font-bold text-lg"
            >
              <Share2 className="w-6 h-6" />
              <span>Share</span>
            </button>
          </div>
      </div>

      {/* Product Showcase Section */}
      <div className={`section-magazine ${activeTab === 'health' || isExporting ? 'active' : ''}`}>
        {renderMagazinePages(products, 'health')}
      </div>

      {/* Elderly Care Section */}
      <div className={`section-magazine ${activeTab === 'elderly' || isExporting ? 'active' : ''}`}>
        {renderMagazinePages(elderlyProducts, 'elderly')}
      </div>

      {/* Cars Section */}
      <div className={`section-magazine ${activeTab === 'cars' || isExporting ? 'active' : ''}`}>
        {renderMagazinePages(carProducts, 'cars')}
      </div>

      {/* Footer */}
      <footer className="bg-white py-16 px-6 border-t border-slate-200 text-center avoid-page-break mt-auto">
        <p className="text-slate-500 text-lg md:text-xl font-medium mb-4">CH-Filter © 2026. جميع الحقوق محفوظة.</p>
        <p className="text-slate-400 text-sm md:text-base max-w-xl mx-auto leading-relaxed">
          نحن نلتزم باختيار المنتجات الأفضل لك. قد نربح عمولة عند التسوق عبر الروابط المذكورة في المجلة.
        </p>
      </footer>

    </div>
    </>
  );
}
