const https = require('https');
const links = [
  "https://amzn.to/43PeM2X?tag=ankj320-20",
  "https://amzn.to/4gy1Rdg?tag=ankj320-20",
  "https://amzn.to/43OaARa?tag=ankj320-20",
  "https://amzn.to/3Sm6ahU?tag=ankj320-20",
  "https://amzn.to/4b0Yp7g?tag=ankj320-20",
  "https://amzn.to/4wmU7Qf?tag=ankj320-20",
  "https://amzn.to/4oCH6PC?tag=ankj320-20",
  "https://amzn.to/4vrNxYu?tag=ankj320-20",
  "https://amzn.to/4vGTpgN?tag=ankj320-20",
  "https://amzn.to/4uQW9a1?tag=ankj320-20"
];

async function getRedirectUrl(url) {
  return new Promise((resolve) => {
    https.get(url, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        resolve(res.headers.location);
      } else {
        resolve(url);
      }
    }).on('error', () => resolve(url));
  });
}

async function fetchHtml(url) {
  return new Promise((resolve) => {
    https.get(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    }, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => resolve(data));
    }).on('error', () => resolve(''));
  });
}

async function run() {
  for (let i = 0; i < links.length; i++) {
    const link = links[i];
    const fullUrl = await getRedirectUrl(link);
    const html = await fetchHtml(fullUrl);
    // Try to find the image URL
    // Look for <img id="landingImage" src="URL"
    const match = html.match(/id="landingImage"[^>]*src="([^"]+)"/);
    let imageUrl = match ? match[1] : "NOT FOUND";
    
    if (imageUrl === "NOT FOUND") {
      const hiResMatch = html.match(/data-old-hires="([^"]+)"/);
      if (hiResMatch) imageUrl = hiResMatch[1];
    }
    console.log(`Product ${i+1}: ${imageUrl}`);
  }
}
run();
